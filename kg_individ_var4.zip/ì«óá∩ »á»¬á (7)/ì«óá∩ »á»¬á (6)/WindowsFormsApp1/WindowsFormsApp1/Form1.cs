﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Lab3D
{
    // Класс для представления трехмерной точки
    public class Point3D
    {
        public double X;
        public double Y;
        public double Z;

        public Point3D(double x, double y, double z)
        {
            X = x;
            Y = y;
            Z = z;
        }
    }

    public partial class Form1 : Form
    {
        // Координаты 5 вершин объемного шестигранника
        Point3D[] vertices = {
            new Point3D(0, 0, 1.5),   // 0 (Передняя центральная вершина)
            new Point3D(0, 1, 0),     // 1 (Верхняя точка)
            new Point3D(1, 0, 0.5),   // 2 (Правая точка)
            new Point3D(0, -1, 0),    // 3 (Нижняя точка)
            new Point3D(-1, 0, 0.5)   // 4 (Левая точка)
        };

        // Индексы вершин треугольных граней 
        int[][] faces = {
            new int[] {0, 2, 1}, // Передняя верхняя правая
            new int[] {0, 3, 2}, // Передняя нижняя правая
            new int[] {0, 4, 3}, // Передняя нижняя левая
            new int[] {0, 1, 4}, // Передняя верхняя левая
            new int[] {1, 3, 4}, // Задняя левая
            new int[] {1, 2, 3}  // Задняя правая
        };

        Point3D[] osVert = {
            new Point3D(0, 0, 0), new Point3D(2.0, 0, 0),
            new Point3D(0, 0, 0), new Point3D(0, 2.0, 0),
            new Point3D(0, 0, 0), new Point3D(0, 0, 2.0)
        };

        double tx = 0, ty = 0, tz = 0;
        double sx = 80, sy = 80, sz = 80;
        double angX = 20, angY = 30, angZ = 0;
        double speedY = 2;
        bool isPlay = true;
        Timer mainTimer;

        public Form1()
        {
            this.Text = "Лабораторная работа 3D - Алгоритм Робертса";
            this.Width = 800;
            this.Height = 600;
            this.DoubleBuffered = true;
            this.StartPosition = FormStartPosition.CenterScreen;

            mainTimer = new Timer();
            mainTimer.Interval = 30;
            mainTimer.Tick += MainTimer_Tick;
            mainTimer.Start();

            this.KeyDown += Form1_KeyDown;
        }

        private void MainTimer_Tick(object sender, EventArgs e)
        {
            if (isPlay)
            {
                angY += speedY;
                if (angY >= 360) angY -= 360;
                if (angY < 0) angY += 360;
            }
            this.Invalidate();
        }

        double[,] UmnozhMatric(double[,] A, double[,] B)
        {
            double[,] C = new double[4, 4];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    C[i, j] = 0;
                    for (int k = 0; k < 4; k++)
                    {
                        C[i, j] += A[i, k] * B[k, j];
                    }
                }
            }
            return C;
        }

        double[,] GetMatrica()
        {
            double[,] mat = new double[4, 4];
            for (int i = 0; i < 4; i++) mat[i, i] = 1;

            double[,] mScale = new double[4, 4];
            mScale[0, 0] = sx; mScale[1, 1] = sy; mScale[2, 2] = sz; mScale[3, 3] = 1;
            mat = UmnozhMatric(mat, mScale);

            double rx = angX * Math.PI / 180.0;
            double[,] mRotX = new double[4, 4];
            mRotX[0, 0] = 1; mRotX[3, 3] = 1;
            mRotX[1, 1] = Math.Cos(rx); mRotX[1, 2] = Math.Sin(rx);
            mRotX[2, 1] = -Math.Sin(rx); mRotX[2, 2] = Math.Cos(rx);
            mat = UmnozhMatric(mat, mRotX);

            double ry = angY * Math.PI / 180.0;
            double[,] mRotY = new double[4, 4];
            mRotY[1, 1] = 1; mRotY[3, 3] = 1;
            mRotY[0, 0] = Math.Cos(ry); mRotY[0, 2] = -Math.Sin(ry);
            mRotY[2, 0] = Math.Sin(ry); mRotY[2, 2] = Math.Cos(ry);
            mat = UmnozhMatric(mat, mRotY);

            double rz = angZ * Math.PI / 180.0;
            double[,] mRotZ = new double[4, 4];
            mRotZ[2, 2] = 1; mRotZ[3, 3] = 1;
            mRotZ[0, 0] = Math.Cos(rz); mRotZ[0, 1] = Math.Sin(rz);
            mRotZ[1, 0] = -Math.Sin(rz); mRotZ[1, 1] = Math.Cos(rz);
            mat = UmnozhMatric(mat, mRotZ);

            double[,] mTrans = new double[4, 4];
            for (int i = 0; i < 4; i++) mTrans[i, i] = 1;
            mTrans[3, 0] = tx;
            mTrans[3, 1] = ty;
            mTrans[3, 2] = tz;
            mat = UmnozhMatric(mat, mTrans);

            return mat;
        }

        Point3D TransformTochka(Point3D p, double[,] m)
        {
            double x = p.X * m[0, 0] + p.Y * m[1, 0] + p.Z * m[2, 0] + m[3, 0];
            double y = p.X * m[0, 1] + p.Y * m[1, 1] + p.Z * m[2, 1] + m[3, 1];
            double z = p.X * m[0, 2] + p.Y * m[1, 2] + p.Z * m[2, 2] + m[3, 2];
            return new Point3D(x, y, z);
        }

        PointF Proekciya(Point3D p)
        {
            float cx = this.ClientSize.Width / 2f;
            float cy = this.ClientSize.Height / 2f;
            return new PointF((float)(cx + p.X), (float)(cy - p.Y));
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // 1. Отрисовка фона
            using (LinearGradientBrush bg = new LinearGradientBrush(this.ClientRectangle, Color.FromArgb(20, 20, 25), Color.Black, 90F))
            {
                g.FillRectangle(bg, this.ClientRectangle);
            }

            // 2. Отрисовка СТАТИЧНЫХ осей на весь экран
            // Оси теперь рисуются относительно центра, используя размеры окна
            float cx = this.ClientSize.Width / 2f;
            float cy = this.ClientSize.Height / 2f;

            // Длина осей теперь зависит от размеров формы (занимают значительную часть экрана)
            float axisLengthX = this.ClientSize.Width * 0.4f;
            float axisLengthY = this.ClientSize.Height * 0.4f;

            using (Pen penX = new Pen(Color.FromArgb(255, 70, 70), 2))
            using (Pen penY = new Pen(Color.FromArgb(70, 255, 70), 2))
            using (Pen penZ = new Pen(Color.FromArgb(50, 160, 255), 2))
            using (var arrow = new AdjustableArrowCap(5, 7, true))
            {
                penX.CustomEndCap = arrow; penY.CustomEndCap = arrow; penZ.CustomEndCap = arrow;

                g.DrawLine(penX, cx, cy, cx + axisLengthX, cy);          // Ось X
                g.DrawLine(penY, cx, cy, cx, cy - axisLengthY);          // Ось Y
                g.DrawLine(penZ, cx, cy, cx - axisLengthX * 0.5f, cy + axisLengthY * 0.5f); // Ось Z

                using (Font fAx = new Font("Segoe UI", 12, FontStyle.Bold))
                {
                    g.DrawString("X", fAx, Brushes.LightSalmon, cx + axisLengthX + 5, cy);
                    g.DrawString("Y", fAx, Brushes.LightGreen, cx, cy - axisLengthY - 20);
                    g.DrawString("Z", fAx, Brushes.LightBlue, cx - axisLengthX * 0.5f - 15, cy + axisLengthY * 0.5f);
                }
            }

            // 3. Расчет матрицы и отрисовка фигуры (как было ранее)
            double[,] mat = GetMatrica();
            Point3D[] wPts = new Point3D[vertices.Length];
            for (int i = 0; i < vertices.Length; i++) wPts[i] = TransformTochka(vertices[i], mat);

            // Центр для алгоритма Робертса
            double wX = 0, wY = 0, wZ = 0;
            foreach (var p in wPts) { wX += p.X; wY += p.Y; wZ += p.Z; }
            wX /= wPts.Length; wY /= wPts.Length; wZ /= wPts.Length;

            double pX = 0, pY = 0, pZ = 10000;

            for (int i = 0; i < faces.Length; i++)
            {
                Point3D v1 = wPts[faces[i][0]], v2 = wPts[faces[i][1]], v3 = wPts[faces[i][2]];
                double vec1X = v1.X - v2.X, vec1Y = v1.Y - v2.Y, vec1Z = v1.Z - v2.Z;
                double vec2X = v3.X - v2.X, vec2Y = v3.Y - v2.Y, vec2Z = v3.Z - v2.Z;

                double A = vec1Y * vec2Z - vec2Y * vec1Z;
                double B = vec1Z * vec2X - vec2Z * vec1X;
                double C = vec1X * vec2Y - vec2X * vec1Y;
                double D = -(A * v1.X + B * v1.Y + C * v1.Z);

                double m = -Math.Sign(A * wX + B * wY + C * wZ + D);
                if (m == 0) m = 1;

                if ((A * m) * pX + (B * m) * pY + (C * m) * pZ + (D * m) > 0)
                {
                    PointF[] pts = { Proekciya(v1), Proekciya(v2), Proekciya(v3) };
                    g.FillPolygon(new SolidBrush(Color.FromArgb(180, 0, 160, 255)), pts);
                    g.DrawPolygon(new Pen(Color.Cyan, 2f), pts);
                }
            }

            // 4. Подсказки управления
            string info = "УПРАВЛЕНИЕ:\n" +
                          "[W/A/S/D] - Перемещение объекта\n" +
                          "[Q/E] - Масштаб X, Z\n" +
                          "[R/F] - Масштаб Y\n" +
                          "[Пробел] - Старт/Стоп\n" +
                          "[Стрелки] - Скорость\n" +
                          "[M] - Отражение Z";

            using (Font fUi = new Font("Consolas", 10, FontStyle.Regular))
            {
                g.DrawString(info, fUi, Brushes.White, 20, 20);
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.W) ty += 10;
            if (e.KeyCode == Keys.S) ty -= 10;
            if (e.KeyCode == Keys.A) tx -= 10;
            if (e.KeyCode == Keys.D) tx += 10;

            if (e.KeyCode == Keys.Q) { sx += 5; sz += 5; }
            if (e.KeyCode == Keys.E) { sx -= 5; sz -= 5; }
            if (e.KeyCode == Keys.R) sy += 5;
            if (e.KeyCode == Keys.F) sy -= 5;

            if (e.KeyCode == Keys.Right) speedY += 0.5;
            if (e.KeyCode == Keys.Left) speedY -= 0.5;

            if (e.KeyCode == Keys.Space) isPlay = !isPlay;

            if (e.KeyCode == Keys.M)
            {
                for (int i = 0; i < vertices.Length; i++)
                {
                    vertices[i].Z = -vertices[i].Z;
                }
            }

            this.Invalidate();
        }
    }
}