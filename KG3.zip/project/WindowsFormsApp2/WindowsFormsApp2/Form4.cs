﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public class Form4 : Form
    {
        private int xn, yn;
        private Bitmap myBitmap;
        private Color currentBorderColor = Color.Red;
        private Color clipOutsideColor = Color.LightGray;

        private int thickness = 1;
        private int dashStep = 10;
        private bool isDrawing = false;

        private List<Point> polyPoints = new List<Point>();
        private Rectangle clipWindow = new Rectangle(50, 50, 200, 200);

        private PictureBox pictureBox1;
        private RadioButton rbAsymDDA, rbPolyFill, rbContour, rbClip;
        private CheckBox cbDashed;
        private TextBox tbThickness, tbDashStep;
        private Button btnColor, btnClear;
        private ColorDialog colorDialog1;

        public Form4()
        {
            InitInterface();
        }

        private void InitInterface()
        {
            this.Text = "Лабораторная работа 2";
            this.Width = 900;
            this.Height = 600;
            this.StartPosition = FormStartPosition.CenterScreen;

            Panel panelRight = new Panel { Dock = DockStyle.Right, Width = 250, BorderStyle = BorderStyle.FixedSingle };
            pictureBox1 = new PictureBox { Dock = DockStyle.Fill, BackColor = Color.White };

            pictureBox1.MouseDown += (s, e) => {
                int.TryParse(tbThickness.Text, out thickness);
                int.TryParse(tbDashStep.Text, out dashStep);

                if (rbAsymDDA.Checked || rbClip.Checked) { xn = e.X; yn = e.Y; isDrawing = true; }
                else if (rbPolyFill.Checked)
                {
                    if (e.Button == MouseButtons.Left)
                    {
                        polyPoints.Add(new Point(e.X, e.Y));
                        if (polyPoints.Count > 1) DDA_Asym(polyPoints[polyPoints.Count - 2].X, polyPoints[polyPoints.Count - 2].Y, e.X, e.Y, currentBorderColor);
                    }
                    else { if (polyPoints.Count > 2) { DDA_Asym(polyPoints.Last().X, polyPoints.Last().Y, polyPoints.First().X, polyPoints.First().Y, currentBorderColor); FillPolygon(); } }
                }
                else if (rbContour.Checked) _ = TraceContourAsync(e.X, e.Y);
            };

            pictureBox1.MouseUp += (s, e) => {
                if (isDrawing)
                {
                    if (rbClip.Checked) Simple2DClipping(xn, yn, e.X, e.Y);
                    else DDA_Asym(xn, yn, e.X, e.Y, currentBorderColor);
                    isDrawing = false;
                }
            };

            GroupBox gbAlgorithms = new GroupBox { Text = "Алгоритмы", Top = 10, Left = 10, Width = 220, Height = 140 };
            rbAsymDDA = new RadioButton { Text = "Несимметричный ЦДА", Top = 20, Left = 10, Width = 200, Checked = true };
            rbPolyFill = new RadioButton { Text = "Закраска многоуг.", Top = 50, Left = 10, Width = 200 };
            rbContour = new RadioButton { Text = "Обход контура", Top = 80, Left = 10, Width = 200 };
            rbClip = new RadioButton { Text = "Простое отсечение", Top = 110, Left = 10, Width = 200 };
            gbAlgorithms.Controls.AddRange(new Control[] { rbAsymDDA, rbPolyFill, rbContour, rbClip });

            GroupBox gbSettings = new GroupBox { Text = "Параметры линии", Top = 160, Left = 10, Width = 220, Height = 150 };
            tbThickness = new TextBox { Text = "1", Top = 20, Left = 130, Width = 50 };
            cbDashed = new CheckBox { Text = "Пунктир", Top = 50, Left = 10 };
            tbDashStep = new TextBox { Text = "10", Top = 75, Left = 130, Width = 50 };
            btnColor = new Button { Text = "Цвет", Top = 110, Left = 10, Width = 100 };
            btnColor.Click += (s, e) => { if (colorDialog1.ShowDialog() == DialogResult.OK) currentBorderColor = colorDialog1.Color; };
            gbSettings.Controls.AddRange(new Control[] { new Label { Text = "Толщина:", Top = 25, Left = 10 }, tbThickness, cbDashed, new Label { Text = "Шаг:", Top = 80, Left = 10 }, tbDashStep, btnColor });

            btnClear = new Button { Text = "Очистить холст", Top = 330, Left = 10, Width = 220, Height = 40 };
            btnClear.Click += (s, e) => ClearBitmap();

            panelRight.Controls.AddRange(new Control[] { gbAlgorithms, gbSettings, btnClear });
            this.Controls.Add(pictureBox1);
            this.Controls.Add(panelRight);

            colorDialog1 = new ColorDialog();
            myBitmap = new Bitmap(2000, 2000);
            ClearBitmap();
        }

        private void ClearBitmap()
        {
            using (Graphics g = Graphics.FromImage(myBitmap))
            {
                g.Clear(Color.FromArgb(247, 249, 239));
                // Рисуем рамку окна отсечения
                g.DrawRectangle(Pens.Blue, clipWindow);
            }
            pictureBox1.Image = myBitmap;
            polyPoints.Clear();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void DrawCustomPixel(int x, int y, Color color)
        {
            if (x < 0 || y < 0 || x >= myBitmap.Width || y >= myBitmap.Height) return;
            if (thickness <= 1) { myBitmap.SetPixel(x, y, color); }
            else
            {
                int offset = thickness / 2;
                for (int i = -offset; i <= offset; i++)
                    for (int j = -offset; j <= offset; j++)
                    {
                        int px = x + i, py = y + j;
                        if (px >= 0 && py >= 0 && px < myBitmap.Width && py < myBitmap.Height)
                            myBitmap.SetPixel(px, py, color);
                    }
            }
        }

        private void DDA_Asym(int xStart, int yStart, int xEnd, int yEnd, Color lineColor)
        {
            int dx = xEnd - xStart, dy = yEnd - yStart;
            int steps = Math.Max(Math.Abs(dx), Math.Abs(dy));
            if (steps == 0) { DrawCustomPixel(xStart, yStart, lineColor); return; }

            float xInc = dx / (float)steps, yInc = dy / (float)steps;
            float x = xStart, y = yStart;

            for (int i = 0; i <= steps; i++)
            {
                if (!cbDashed.Checked || (i % (dashStep * 2) < dashStep))
                    DrawCustomPixel((int)Math.Round(x), (int)Math.Round(y), lineColor);

                x += xInc;
                y += yInc;
            }
            pictureBox1.Invalidate();
        }

        // --- Алгоритм простого поточечного отсечения ---
        private void Simple2DClipping(int x1, int y1, int x2, int y2)
        {
            int dx = x2 - x1, dy = y2 - y1;
            int steps = Math.Max(Math.Abs(dx), Math.Abs(dy));
            if (steps == 0)
            {
                Color c = IsPointInside(x1, y1) ? currentBorderColor : clipOutsideColor;
                DrawCustomPixel(x1, y1, c);
                return;
            }

            float xInc = dx / (float)steps, yInc = dy / (float)steps;
            float x = x1, y = y1;

            for (int i = 0; i <= steps; i++)
            {
                int curX = (int)Math.Round(x);
                int curY = (int)Math.Round(y);

                // Проверка пунктира (если включен)
                if (!cbDashed.Checked || (i / dashStep) % 2 == 0)
                {
                    // Проверка: находится ли точка внутри окна отсечения
                    if (IsPointInside(curX, curY))
                        DrawCustomPixel(curX, curY, currentBorderColor);
                    else
                        DrawCustomPixel(curX, curY, clipOutsideColor);
                }

                x += xInc;
                y += yInc;
            }
            pictureBox1.Invalidate();
        }

        private bool IsPointInside(int x, int y)
        {
            return x >= clipWindow.Left && x <= clipWindow.Right &&
                   y >= clipWindow.Top && y <= clipWindow.Bottom;
        }

        private void FillPolygon()
        {
            if (polyPoints.Count < 3) return;
            int minY = polyPoints.Min(p => p.Y), maxY = polyPoints.Max(p => p.Y);
            for (int y = minY; y <= maxY; y++)
            {
                var inters = new List<int>();
                for (int i = 0; i < polyPoints.Count; i++)
                {
                    Point p1 = polyPoints[i], p2 = polyPoints[(i + 1) % polyPoints.Count];
                    if ((p1.Y <= y && p2.Y > y) || (p2.Y <= y && p1.Y > y))
                        inters.Add((int)(p1.X + (float)(y - p1.Y) / (p2.Y - p1.Y) * (p2.X - p1.X)));
                }
                inters.Sort();
                for (int i = 0; i < inters.Count - 1; i += 2)
                    for (int x = inters[i]; x <= inters[i + 1]; x++) DrawCustomPixel(x, y, currentBorderColor);
            }
            pictureBox1.Invalidate();
        }

        private async Task TraceContourAsync(int startX, int startY)
        {
            if (startX < 0 || startX >= myBitmap.Width || startY < 0 || startY >= myBitmap.Height) return;
            Color target = myBitmap.GetPixel(startX, startY);
            if (target.ToArgb() == Color.FromArgb(247, 249, 239).ToArgb()) return;

            var stack = new Stack<Point>(); stack.Push(new Point(startX, startY));
            var visited = new HashSet<Point>();
            while (stack.Count > 0)
            {
                Point p = stack.Pop();
                if (p.X < 0 || p.X >= myBitmap.Width || p.Y < 0 || p.Y >= myBitmap.Height || visited.Contains(p)) continue;
                visited.Add(p);
                if (myBitmap.GetPixel(p.X, p.Y).ToArgb() == target.ToArgb())
                {
                    myBitmap.SetPixel(p.X, p.Y, Color.Green);
                    if (visited.Count % 100 == 0) { pictureBox1.Invalidate(); await Task.Delay(1); }
                    stack.Push(new Point(p.X + 1, p.Y)); stack.Push(new Point(p.X - 1, p.Y));
                    stack.Push(new Point(p.X, p.Y + 1)); stack.Push(new Point(p.X, p.Y - 1));
                }
            }
            pictureBox1.Invalidate();
        }
    }
}