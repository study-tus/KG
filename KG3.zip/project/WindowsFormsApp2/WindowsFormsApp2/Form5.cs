﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            this.DoubleBuffered = true;
            InitializeComponent();
            this.KeyPreview = true;
            this.KeyDown += Form5_KeyDown;
            timer1.Interval = 20;
        }

        private enum TaskMode { None, Task1, Task4, Task6, Task13 }
        private TaskMode currentTask = TaskMode.None;

        float boatX = -200, birdX = -100, birdY = 100, birdScale = 1.0f, sunY = 50;
        float angle1 = 0, angle2 = 0, speed1 = 2f, speed2 = -2f, size1 = 150f, size2 = 50f;
        int hexCount = 1;
        float bgOffset = 0, wheelAngle = 0;

        private void button1_Click(object sender, EventArgs e) => StartTask(TaskMode.Task1);
        private void button2_Click(object sender, EventArgs e) => StartTask(TaskMode.Task4);
        private void button3_Click(object sender, EventArgs e) => StartTask(TaskMode.Task6);
        private void button4_Click(object sender, EventArgs e) => StartTask(TaskMode.Task13);
        private void button5_Click(object sender, EventArgs e) => StartTask(TaskMode.None);

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (currentTask == TaskMode.Task1)
            {
                boatX += 3; birdX += 4; sunY += 0.5f;
                birdScale -= 0.003f; if (birdScale < 0) birdScale = 0;
            }
            else if (currentTask == TaskMode.Task4)
            {
                speed1 = (float)nudSpeed1.Value;
                speed2 = (float)nudSpeed2.Value;
                angle1 += speed1;
                angle2 += speed2;

                if (size2 < 150) size2 += 0.5f;
                if (size1 > 50) size1 -= 0.5f;
            }
            else if (currentTask == TaskMode.Task6)
            {
                if (hexCount < 40) hexCount++;
            }
            else if (currentTask == TaskMode.Task13)
            {
                bgOffset -= 2f;
                if (bgOffset <= -200) bgOffset += 200;
                wheelAngle += 3f;
            }

            Invalidate();
        }

        private void StartTask(TaskMode mode)
        {
            currentTask = mode;
            timer1.Stop();

            boatX = -100; birdX = -50; birdY = 100; birdScale = 1.0f; sunY = 50;
            angle1 = 0; angle2 = 0; size1 = 150f; size2 = 50f; speed1 = 2f; speed2 = -2f;
            hexCount = 1; bgOffset = 0; wheelAngle = 0;

            if (mode != TaskMode.None) timer1.Start();
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Если цвет не выбран — выходим
            if (comboBox1.SelectedItem == null) return;

            // Толщина не может быть 0 или отрицательной
            float penWidth = Math.Max(1, (float)numericUpDown1.Value);
            Color c = Color.FromName(comboBox1.SelectedItem.ToString());

            using (Pen mainPen = new Pen(c, penWidth))
            {
                // Если выбран прерывистый стиль
                if (comboBox2.SelectedIndex == 1)
                {
                    float dashStep = Math.Max(1, (float)numericUpDown2.Value); // шаг тоже не 0
                    mainPen.DashPattern = new float[] { dashStep, dashStep };
                }

                // Надпись ТУСУР
                if (checkBox1.Checked)
                    g.DrawString("62 года ТУСУР", new Font("Arial", 16, FontStyle.Bold), Brushes.DarkBlue, 10, 150);

                // Отрисовка задач (передаём mainPen)
                if (currentTask == TaskMode.Task1) DrawTask1(g, mainPen);
                if (currentTask == TaskMode.Task4) DrawTask4(g, mainPen);
                if (currentTask == TaskMode.Task6) DrawTask6(g, mainPen);
                if (currentTask == TaskMode.Task13) DrawTask13(g, mainPen);
            }
        }

        private void Form5_KeyDown(object sender, KeyEventArgs e)
        {
            if (currentTask != TaskMode.Task4) return;

            decimal delta = 0.5m;
            if (e.KeyCode == Keys.W) nudSpeed1.Value = Math.Min(nudSpeed1.Value + delta, nudSpeed1.Maximum);
            if (e.KeyCode == Keys.S) nudSpeed1.Value = Math.Max(nudSpeed1.Value - delta, nudSpeed1.Minimum);
            if (e.KeyCode == Keys.Up) nudSpeed2.Value = Math.Min(nudSpeed2.Value + delta, nudSpeed2.Maximum);
            if (e.KeyCode == Keys.Down) nudSpeed2.Value = Math.Max(nudSpeed2.Value - delta, nudSpeed2.Minimum);
        }

        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void numericUpDown2_ValueChanged(object sender, EventArgs e) { }
        private void numericUpDown1_ValueChanged(object sender, EventArgs e) { }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e) { }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void checkBox1_CheckedChanged(object sender, EventArgs e) { }

        private void DrawBird(Graphics g, float x, float y, float scale, Pen pen)
        {
            if (scale <= 0) return;
            var state = g.Save();
            g.TranslateTransform(x, y);
            g.ScaleTransform(scale, scale);
            g.DrawArc(pen, -20, -10, 20, 20, 180, 140); // Левое крыло
            g.DrawArc(pen, 0, -10, 20, 20, 220, 140);  // Правое крыло
            g.Restore(state);
        }

        private void DrawTask1(Graphics g, Pen pen)
        {
            g.FillRectangle(Brushes.Coral, 0, 0, ClientSize.Width, 300);
            g.FillEllipse(Brushes.Gold, 400, sunY + 50, 100, 100);
            g.FillRectangle(Brushes.SteelBlue, 0, 300, ClientSize.Width, ClientSize.Height);

            var state = g.Save();
            g.TranslateTransform(boatX, 260);
            g.FillPolygon(Brushes.SaddleBrown, new PointF[] { new PointF(0, 50), new PointF(100, 50), new PointF(80, 80), new PointF(20, 80) });
            g.DrawLine(pen, 50, 50, 50, -50);
            g.FillPolygon(Brushes.White, new PointF[] { new PointF(50, -50), new PointF(50, 40), new PointF(100, 40) });
            g.Restore(state);

            DrawBird(g, birdX, birdY, birdScale, pen);
        }

        private void DrawTask4(Graphics g, Pen pen)
        {
            g.TranslateTransform(ClientSize.Width / 2, ClientSize.Height / 2 + 50);

            var state = g.Save();
            g.RotateTransform(angle1);
            DrawPolygon(g, pen, 3, size1);
            g.Restore(state);

            state = g.Save();
            g.RotateTransform(angle2);
            DrawPolygon(g, Pens.DarkCyan, 3, size2);
            g.Restore(state);
            // Второй треугольник (вращается в другую сторону)
            state = g.Save();
            g.RotateTransform(angle2);
            using (Pen secondPen = new Pen(Color.DarkCyan, pen.Width))
            {
                if (pen.DashStyle == DashStyle.Custom)
                    secondPen.DashPattern = pen.DashPattern;
                DrawPolygon(g, secondPen, 3, size2);
            }
            g.Restore(state);
        }

        private void DrawTask6(Graphics g, Pen pen)
        {
            g.TranslateTransform(ClientSize.Width / 2, ClientSize.Height / 2 + 50);
            float.TryParse(textBox1.Text, out float angleB);
            Random rnd = new Random(123);

            for (int i = 0; i < hexCount; i++)
            {
                var state = g.Save();
                g.RotateTransform(i * angleB);
                using (Pen p = new Pen(Color.FromArgb(rnd.Next(100, 255), rnd.Next(100, 255), rnd.Next(100, 255)), pen.Width))
                {
                    if (comboBox2.SelectedIndex == 1)
                        p.DashPattern = new float[] { (float)numericUpDown2.Value, (float)numericUpDown2.Value };

                    DrawPolygon(g, p, 6, 10 + i * 8);
                }
                g.Restore(state);
            }
        }

        private void DrawTask13(Graphics g, Pen pen)
        {
            int centerY = ClientSize.Height / 2 + 100;

            g.FillRectangle(Brushes.LightSkyBlue, 0, 0, ClientSize.Width, centerY + 45);
            g.FillRectangle(Brushes.ForestGreen, 0, centerY + 45, ClientSize.Width, ClientSize.Height);

            DrawScrollingTrees(g, centerY + 80);

            g.FillRectangle(Brushes.Gray, 0, centerY + 45, ClientSize.Width, 12);
            for (int i = -100; i < ClientSize.Width + 100; i += 50)
            {
                float xShpala = i + (bgOffset % 50);
                g.FillRectangle(Brushes.SaddleBrown, xShpala, centerY + 48, 25, 8);
                g.FillRectangle(Brushes.Black, xShpala, centerY + 48, 25, 2);
            }
            g.DrawLine(new Pen(Color.Silver, 3), 0, centerY + 46, ClientSize.Width, centerY + 46);

            int wagonX = 50;
            DrawTransparentWagonBody(g, wagonX, centerY);
            g.DrawLine(new Pen(Color.Black, 6), wagonX + 160, centerY + 10, wagonX + 190, centerY + 10);
            int cabinX = wagonX + 190;
            DrawTransparentCabin(g, cabinX, centerY);
            int boilerX = cabinX + 80;
            g.FillRectangle(Brushes.Firebrick, boilerX, centerY - 60, 140, 80);
            g.DrawRectangle(Pens.Black, boilerX, centerY - 60, 140, 80);
            g.FillRectangle(Brushes.Black, boilerX + 100, centerY - 95, 20, 40);
            if (wheelAngle % 60 < 30)
                g.FillEllipse(Brushes.LightGray, boilerX + 90, centerY - 130, 40, 20);

            float wheel1X = wagonX + 40;
            float wheel2X = wagonX + 120;
            float wheel3X = cabinX + 40;
            float wheel4X = boilerX + 30;
            float wheel5X = boilerX + 100;

            DrawWheel(g, wheel1X, centerY + 25, wheelAngle);
            DrawWheel(g, wheel2X, centerY + 25, wheelAngle);
            DrawWheel(g, wheel3X, centerY + 25, wheelAngle);
            DrawWheel(g, wheel4X, centerY + 25, wheelAngle);
            DrawWheel(g, wheel5X, centerY + 25, wheelAngle);

            DrawConnectingRod(g, wheel3X, centerY + 25, wheel5X, centerY + 25, wheelAngle, wheelAngle + 90);
        }

        private void DrawTransparentWagonBody(Graphics g, int x, int centerY)
        {
            Rectangle bodyRect = new Rectangle(x, centerY - 80, 160, 100);
            Rectangle[] windowRects = new Rectangle[]
            {
                new Rectangle(x + 20, centerY - 60, 40, 40),
                new Rectangle(x + 100, centerY - 60, 40, 40)
            };

            Region originalClip = g.Clip;
            using (Region region = new Region(bodyRect))
            {
                foreach (var wr in windowRects)
                    region.Exclude(wr);
                g.SetClip(region, CombineMode.Replace);
                g.FillRectangle(Brushes.DarkOliveGreen, bodyRect);
            }
            g.Clip = originalClip;

            foreach (var wr in windowRects)
                g.DrawRectangle(Pens.Black, wr);
            g.DrawRectangle(Pens.Black, bodyRect);
        }

        private void DrawTransparentCabin(Graphics g, int x, int centerY)
        {
            Rectangle bodyRect = new Rectangle(x, centerY - 110, 80, 130);
            Rectangle windowRect = new Rectangle(x + 40, centerY - 90, 30, 40);

            Region originalClip = g.Clip;
            using (Region region = new Region(bodyRect))
            {
                region.Exclude(windowRect);
                g.SetClip(region, CombineMode.Replace);
                g.FillRectangle(Brushes.DarkRed, bodyRect);
            }
            g.Clip = originalClip;

            g.DrawRectangle(Pens.Black, windowRect);
            g.DrawRectangle(Pens.Black, bodyRect);
        }

        private void DrawScrollingTrees(Graphics g, float groundY)
        {
            float spacing = 200f;
            float offset = ((bgOffset % spacing) + spacing) % spacing;

            int index = 0;
            for (float tx = -spacing; tx < ClientSize.Width + spacing; tx += spacing)
            {
                float x = tx + offset;
                DrawTree(g, x, groundY, index++);
            }
        }

        private void DrawTree(Graphics g, float x, float groundY, int seed)
        {
            int type = seed % 3;
            float trunkHeight = 80 + (seed % 3) * 30f;
            float trunkWidth = 10 + (seed % 3) * 4f;

            using (Brush trunkBrush = new SolidBrush(Color.FromArgb(139, 69, 19)))
            {
                g.FillRectangle(trunkBrush, x - trunkWidth / 2, groundY - trunkHeight, trunkWidth, trunkHeight);
            }

            switch (type)
            {
                case 0:
                    using (Brush foliage = new SolidBrush(Color.FromArgb(0, 100, 0)))
                    {
                        g.FillEllipse(foliage, x - 30, groundY - trunkHeight - 40, 60, 80);
                    }
                    break;
                case 1:
                    using (Brush foliage = new SolidBrush(Color.FromArgb(34, 139, 34)))
                    {
                        PointF[] triangle = {
                            new PointF(x, groundY - trunkHeight - 50),
                            new PointF(x - 35, groundY - trunkHeight + 10),
                            new PointF(x + 35, groundY - trunkHeight + 10)
                        };
                        g.FillPolygon(foliage, triangle);
                    }
                    break;
                case 2:
                    using (Brush foliage = new SolidBrush(Color.FromArgb(107, 142, 35)))
                    {
                        g.FillEllipse(foliage, x - 25, groundY - trunkHeight - 30, 50, 50);
                        g.FillEllipse(foliage, x - 20, groundY - trunkHeight - 50, 40, 40);
                    }
                    break;
            }
        }

        private void DrawConnectingRod(Graphics g, float x1, float y1, float x2, float y2, float angle1, float angle2, float crankRadius = 15f)
        {
            double rad1 = angle1 * Math.PI / 180f;
            double rad2 = angle2 * Math.PI / 180f;
            float px1 = x1 + crankRadius * (float)Math.Cos(rad1);
            float py1 = y1 + crankRadius * (float)Math.Sin(rad1);
            float px2 = x2 + crankRadius * (float)Math.Cos(rad2);
            float py2 = y2 + crankRadius * (float)Math.Sin(rad2);

            using (Pen rodPen = new Pen(Color.DarkSlateGray, 5))
                g.DrawLine(rodPen, px1, py1, px2, py2);
        }

        private void DrawPolygon(Graphics g, Pen p, int sides, float radius)
        {
            PointF[] pts = new PointF[sides];
            for (int i = 0; i < sides; i++)
            {
                double rad = (i * 360f / sides - 90) * Math.PI / 180;
                pts[i] = new PointF((float)(radius * Math.Cos(rad)), (float)(radius * Math.Sin(rad)));
            }
            g.DrawPolygon(p, pts);
        }

        private void DrawWheel(Graphics g, float x, float y, float angle)
        {
            g.FillEllipse(Brushes.Black, x - 30, y - 30, 60, 60);
            var state = g.Save();
            g.TranslateTransform(x, y);
            g.RotateTransform(angle);
            g.DrawLine(Pens.White, -25, 0, 25, 0);
            g.DrawLine(Pens.White, 0, -25, 0, 25);
            g.Restore(state);
        }
    }
}