﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            this.DoubleBuffered = true;
            this.KeyPreview = true; // ВАЖНО: Разрешаем форме перехватывать нажатия клавиш!
            this.KeyDown += new KeyEventHandler(Form5_KeyDown); // Подключаем обработчик клавиатуры
            InitializeComponent();

            // Заполняем стили линий
            if (comboBox2.Items.Count == 0)
            {
                comboBox2.Items.AddRange(new string[] { "Сплошная", "Пунктир" });
                comboBox2.SelectedIndex = 0;
            }
        }

        // --- СОСТОЯНИЕ ПРИЛОЖЕНИЯ ---
        private enum TaskMode { None, Task1, Task4, Task6, Task13 }
        private TaskMode currentTask = TaskMode.None;

        // --- ПЕРЕМЕННЫЕ АНИМАЦИИ ---
        float boatX = -200, birdX = -100, birdY = 100, birdScale = 1.0f, sunY = 50;
        float angle1 = 0, angle2 = 0, speed1 = 2f, speed2 = -2f, size1 = 150f, size2 = 50f;
        int hexCount = 1;
        float bgOffset = 0, wheelAngle = 0;

        // --- ОБРАБОТЧИКИ КНОПОК ---
        private void button1_Click(object sender, EventArgs e) => StartTask(TaskMode.Task1);
        private void button2_Click(object sender, EventArgs e) => StartTask(TaskMode.Task4);
        private void button3_Click(object sender, EventArgs e) => StartTask(TaskMode.Task6);
        private void button4_Click(object sender, EventArgs e) => StartTask(TaskMode.Task13);
        private void button5_Click(object sender, EventArgs e) => StartTask(TaskMode.None);

        // --- УПРАВЛЕНИЕ КЛАВИАТУРОЙ (Для Задания 4) ---
        private void Form5_KeyDown(object sender, KeyEventArgs e)
        {
            if (currentTask != TaskMode.Task4) return;

            // Треугольник 1 (Внутренний): Клавиши W и S
            if (e.KeyCode == Keys.W) speed1 += 0.5f; // Увеличиваем скорость (в одну сторону)
            if (e.KeyCode == Keys.S) speed1 -= 0.5f; // Уменьшаем скорость (и меняем направление при минусе)

            // Треугольник 2 (Внешний): Стрелки Вверх и Вниз
            if (e.KeyCode == Keys.Up) speed2 += 0.5f;
            if (e.KeyCode == Keys.Down) speed2 -= 0.5f;
        }

        // --- ТАЙМЕР ---
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (currentTask == TaskMode.Task1)
            {
                boatX += 3; birdX += 4; sunY += 0.5f;
                birdScale -= 0.003f; if (birdScale < 0) birdScale = 0;
            }
            else if (currentTask == TaskMode.Task4)
            {
                // Скорость теперь меняется НЕ с интерфейса, а с клавиатуры!
                angle1 += speed1;
                angle2 += speed2;

                if (size2 < 150) size2 += 0.5f;
                if (size1 > 50) size1 -= 0.5f;
            }
            else if (currentTask == TaskMode.Task6)
            {
                if (hexCount < 40) hexCount++;
            }
            else if (currentTask == TaskMode.Task13)
            {
                bgOffset -= 8;
                if (bgOffset <= -150) bgOffset = 0; // Цикл для деревьев и рельс
                wheelAngle += 15;
            }
            Invalidate();
        }

        private void StartTask(TaskMode mode)
        {
            currentTask = mode;
            timer1.Stop();

            boatX = -100; birdX = -50; birdY = 100; birdScale = 1.0f; sunY = 50;
            angle1 = 0; angle2 = 0; size1 = 150f; size2 = 50f; speed1 = 2f; speed2 = -2f;
            hexCount = 1; bgOffset = 0; wheelAngle = 0;

            if (mode != TaskMode.None) timer1.Start();
            Invalidate();
        }

        // --- ГРАФИЧЕСКИЙ ДВИЖОК (OnPaint) ---
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            // Очистка фона, чтобы надпись была видна всегда
            g.Clear(Color.WhiteSmoke);

            // Рисуем выбранную задачу
            if (comboBox1.SelectedItem != null)
            {
                Color c = Color.FromName(comboBox1.SelectedItem.ToString());
                using (Pen mainPen = new Pen(c, (float)numericUpDown1.Value))
                {
                    if (comboBox2.SelectedIndex == 1 && (float)numericUpDown2.Value > 0)
                    {
                        float d = (float)numericUpDown2.Value;
                        mainPen.DashPattern = new float[] { d, d };
                    }

                    if (currentTask == TaskMode.Task1) DrawTask1(g, mainPen);
                    if (currentTask == TaskMode.Task4) DrawTask4(g, mainPen);
                    if (currentTask == TaskMode.Task6) DrawTask6(g, mainPen);
                    if (currentTask == TaskMode.Task13) DrawTask13(g, mainPen);
                }
            }

            // РИСУЕМ ЛОГОТИП И ТЕКСТ (Поверх всего)
            if (checkBox1.Checked)
            {
                // Текст рисуем в любом случае
                g.DrawString("62 года ТУСУР", new Font("Arial", 18, FontStyle.Bold), Brushes.DarkBlue, 300, 300);

                try
                {
                    // Пытаемся найти логотип в папке запуска
                    string logoPath = System.IO.Path.Combine(Application.StartupPath, "tusur_logo.png");
                    if (System.IO.File.Exists(logoPath))
                    {
                        using (Image logo = Image.FromFile(logoPath))
                        {
                            g.DrawImage(logo, 350, 350, 80, 80);
                        }
                    }
                    else
                    {
                    }
                }
                catch { /* Ошибка загрузки */ }
            }
        }


        // Пустые методы для дизайнера
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void numericUpDown2_ValueChanged(object sender, EventArgs e) => Invalidate();
        private void numericUpDown1_ValueChanged(object sender, EventArgs e) { }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e) => Invalidate();
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void checkBox1_CheckedChanged(object sender, EventArgs e) { }

        // --- МЕТОДЫ ОТРИСОВКИ ---

        private void DrawBird(Graphics g, float x, float y, float scale)
        {
            if (scale <= 0) return;
            var state = g.Save();
            g.TranslateTransform(x, y);
            g.ScaleTransform(scale, scale);
            Pen birdPen = new Pen(Color.Black, 2);
            g.DrawArc(birdPen, -20, 0, 20, 20, 180, 140);
            g.DrawArc(birdPen, 0, 0, 20, 20, 220, 140);
            g.Restore(state);
        }

        private void DrawTask1(Graphics g, Pen pen)
        {
            // Фон: небо и море
            g.FillRectangle(Brushes.Coral, 0, 0, ClientSize.Width, 300);
            g.FillEllipse(Brushes.Gold, 400, sunY + 50, 100, 100);
            g.FillRectangle(Brushes.SteelBlue, 0, 300, ClientSize.Width, ClientSize.Height);

            // Отрисовка лодки
            var state = g.Save();
            g.TranslateTransform(boatX, 260); // Лодка плывет по X
            // Корпус
            g.FillPolygon(Brushes.SaddleBrown, new PointF[] { new PointF(0, 50), new PointF(100, 50), new PointF(80, 80), new PointF(20, 80) });
            // Мачта и парус
            g.DrawLine(pen, 50, 50, 50, -50);
            g.FillPolygon(Brushes.White, new PointF[] { new PointF(50, -50), new PointF(50, 40), new PointF(100, 40) });
            g.Restore(state);

            DrawBird(g, birdX, birdY, birdScale); // Рисуем чайку
        }

        private void DrawTask4(Graphics g, Pen pen)
        {
            g.TranslateTransform(ClientSize.Width / 2, ClientSize.Height / 2 + 50);

            var state = g.Save();
            g.RotateTransform(angle1);
            DrawPolygon(g, pen, 3, size1);
            g.Restore(state);

            state = g.Save();
            g.RotateTransform(angle2);
            DrawPolygon(g, pen, 3, size2);
            g.Restore(state);

            // Инструкция на экране
            g.ResetTransform();
            g.DrawString("Управление: W/S (внутренний), Стрелки Вверх/Вниз (внешний)", new Font("Arial", 10), Brushes.Black, 10, 10);
        }

        private void DrawTask6(Graphics g, Pen pen)
        {
            g.TranslateTransform(ClientSize.Width / 2, ClientSize.Height / 2 + 50);
            float.TryParse(textBox1.Text, out float angleB);
            Random rnd = new Random(123);

            for (int i = 0; i < hexCount; i++)
            {
                var state = g.Save();
                g.RotateTransform(i * angleB);
                using (Pen p = new Pen(Color.FromArgb(rnd.Next(100, 255), rnd.Next(100, 255), rnd.Next(100, 255)), pen.Width))
                {
                    if (comboBox2.SelectedIndex == 1) p.DashPattern = new float[] { (float)numericUpDown2.Value, (float)numericUpDown2.Value };
                    DrawPolygon(g, p, 6, 10 + i * 8);
                }
                g.Restore(state);
            }
        }

        private void DrawTask13(Graphics g, Pen pen)
        {
            // 1. ПОДГОТОВКА ФОНА
            int centerY = ClientSize.Height / 2 + 100;
            // Чистое небо
            g.FillRectangle(Brushes.LightCyan, 0, 0, ClientSize.Width, centerY + 45);

            // 2. ОТРИСОВКА ЛЕСА (Плавное движение по аналогии с рельсами)
            int treeStep = 300; // Расстояние между деревьями
            for (int i = -treeStep; i < ClientSize.Width + treeStep; i += treeStep)
            {
                // Смещение точно такое же, как у рельсов/шпал
                float treeX = i + (bgOffset % treeStep);

                // Ствол
                g.FillRectangle(Brushes.SaddleBrown, treeX + 40, centerY - 65, 12, 110);
                // Пышная крона (сделаем два круга для объема)
                g.FillEllipse(Brushes.ForestGreen, treeX, centerY - 130, 95, 95);
                g.FillEllipse(Brushes.DarkGreen, treeX + 20, centerY - 145, 70, 70);
            }

            // 3. РЕЛЬСЫ И ШПАЛЫ (Твой рабочий код для плавности)
            g.FillRectangle(Brushes.Gray, 0, centerY + 45, ClientSize.Width, 12);
            int shpalaStep = 60;
            for (int i = -shpalaStep; i < ClientSize.Width + shpalaStep; i += shpalaStep)
            {
                float xShpala = i + (bgOffset % shpalaStep);
                g.FillRectangle(Brushes.SaddleBrown, xShpala, centerY + 48, 30, 8);
            }

            // 4. ПОЕЗД (Рисуем ПОВЕРХ деревьев)
            int wagonX = 70;

            // ВАГОН
            g.FillRectangle(Brushes.DarkOliveGreen, wagonX, centerY - 85, 170, 105);
            g.DrawRectangle(pen, wagonX, centerY - 85, 170, 105);

            // ПРОЗРАЧНЫЕ ОКНА (Здесь магия просвечивания)
            // 50 - это уровень прозрачности (от 0 до 255)
            using (Brush windowGlass = new SolidBrush(Color.FromArgb(50, Color.LightSkyBlue)))
            {
                // Окна вагона
                g.FillRectangle(windowGlass, wagonX + 20, centerY - 70, 55, 55);
                g.DrawRectangle(pen, wagonX + 20, centerY - 70, 55, 55);

                g.FillRectangle(windowGlass, wagonX + 95, centerY - 70, 55, 55);
                g.DrawRectangle(pen, wagonX + 95, centerY - 70, 55, 55);
            }

            // СЦЕПКА (Черная балка между вагоном и кабиной)
            g.FillRectangle(Brushes.Black, wagonX + 170, centerY + 5, 35, 12);

            // ЛОКОМОТИВ
            int cabinX = wagonX + 205;
            // Кабина
            g.FillRectangle(Brushes.DarkRed, cabinX, centerY - 115, 95, 135);
            g.DrawRectangle(pen, cabinX, centerY - 115, 95, 135);

            // Окно кабины (тоже прозрачное)
            using (Brush windowGlass = new SolidBrush(Color.FromArgb(10, Color.LightSkyBlue)))
            {
                g.FillRectangle(windowGlass, cabinX + 15, centerY - 100, 50, 60);
                g.DrawRectangle(pen, cabinX + 15, centerY - 100, 50, 60);
            }

            // Котел и труба
            int boilerX = cabinX + 95;
            g.FillRectangle(Brushes.Firebrick, boilerX, centerY - 70, 150, 90);
            g.DrawRectangle(pen, boilerX, centerY - 70, 150, 90);
            g.FillRectangle(Brushes.Black, boilerX + 100, centerY - 100, 30, 40);

            // 5. КОЛЕСА И ШАТУН
            float[] wheels = { wagonX + 45, wagonX + 130, cabinX + 45, boilerX + 45, boilerX + 115 };
            foreach (float wx in wheels) DrawWheel(g, wx, centerY + 28, wheelAngle);

            // Стальной шатун локомотива
            double rad = wheelAngle * Math.PI / 180.0;
            float r = 16f;
            float x1 = wheels[2] + (float)(r * Math.Cos(rad));
            float y1 = (centerY + 28) + (float)(r * Math.Sin(rad));
            float x3 = wheels[4] + (float)(r * Math.Cos(rad));
            float y3 = (centerY + 28) + (float)(r * Math.Sin(rad));

            using (Pen rodPen = new Pen(Color.Silver, 6))
                g.DrawLine(rodPen, x1, y1, x3, y3);
        }


        private void DrawPolygon(Graphics g, Pen p, int sides, float radius)
        {
            PointF[] pts = new PointF[sides];
            for (int i = 0; i < sides; i++)
            {
                double rad = (i * 360f / sides - 90) * Math.PI / 180;
                pts[i] = new PointF((float)(radius * Math.Cos(rad)), (float)(radius * Math.Sin(rad)));
            }
            g.DrawPolygon(p, pts);
        }

        private void DrawWheel(Graphics g, float x, float y, float angle)
        {
            g.FillEllipse(Brushes.Black, x - 30, y - 30, 60, 60);
            var state = g.Save();
            g.TranslateTransform(x, y);
            g.RotateTransform(angle);
            g.DrawLine(Pens.White, -25, 0, 25, 0);
            g.DrawLine(Pens.White, 0, -25, 0, 25);
            g.Restore(state);
        }
    }
}