﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            // Включаем двойную буферизацию. 
            // Без неё экран будет мерцать, так как Windows сначала стирает фон, а потом рисует.
            // При true графика сначала готовится в памяти, а потом выводится целиком.
            this.DoubleBuffered = true;

            InitializeComponent(); // Инициализация элементов управления (кнопок, комбобоксов и т.д.)
        }

        // --- СОСТОЯНИЕ ПРИЛОЖЕНИЯ ---
        // Перечисление помогает нам четко знать, какую задачу мы сейчас визуализируем.
        private enum TaskMode { None, Task1, Task4, Task6, Task13 }
        private TaskMode currentTask = TaskMode.None;

        // --- ПЕРЕМЕННЫЕ АНИМАЦИИ ---
        // Эти значения меняются внутри таймера, создавая иллюзию движения.
        float boatX = -200, birdX = -100, birdY = 100, birdScale = 1.0f, sunY = 50; // Для лодки
        float angle1 = 0, angle2 = 0, speed1 = 2f, speed2 = -2f, size1 = 150f, size2 = 50f; // Для треугольников
        int hexCount = 1; // Количество шестиугольников
        float bgOffset = 0, wheelAngle = 0; // Для поезда (движение рельс и вращение колес)

        // --- ОБРАБОТЧИКИ СОБЫТИЙ КНОПОК ---
        // Каждая кнопка просто передает нужный режим в метод StartTask.
        private void button1_Click(object sender, EventArgs e) => StartTask(TaskMode.Task1);  // Запуск Лодки
        private void button2_Click(object sender, EventArgs e) => StartTask(TaskMode.Task4);  // Запуск Треугольников
        private void button3_Click(object sender, EventArgs e) => StartTask(TaskMode.Task6);  // Запуск Шестиугольников
        private void button4_Click(object sender, EventArgs e) => StartTask(TaskMode.Task13); // Запуск Поезда
        private void button5_Click(object sender, EventArgs e) => StartTask(TaskMode.None);   // Стоп/Сброс

        // --- ТАЙМЕР (СЕРДЦЕ АНИМАЦИИ) ---
        // Срабатывает каждые N миллисекунд (Interval). Здесь мы обновляем только логику/координаты.
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (currentTask == TaskMode.Task1) // Движение лодки, птицы и солнца
            {
                boatX += 3; birdX += 4; sunY += 0.5f;
                birdScale -= 0.003f; if (birdScale < 0) birdScale = 0;
            }
            else if (currentTask == TaskMode.Task4) // Вращение и изменение размера треугольников
            {
                // Считываем скорость с элементов NumericUpDown (nudSpeed1 и nudSpeed2)
                speed1 = (float)nudSpeed1.Value;
                speed2 = (float)nudSpeed2.Value;
                angle1 += speed1;
                angle2 += speed2;

                if (size2 < 150) size2 += 0.5f;
                if (size1 > 50) size1 -= 0.5f;
            }
            else if (currentTask == TaskMode.Task6) // Постепенное добавление фигур
            {
                if (hexCount < 40) hexCount++;
            }
            else if (currentTask == TaskMode.Task13) // Имитация движения поезда
            {
                bgOffset -= 8; // Сдвигаем рельсы влево (эффект езды вправо)
                if (bgOffset <= -50) bgOffset = 0;
                wheelAngle += 15; // Крутим колеса
            }

            // Invalidate() говорит Windows: "Картинка устарела, вызови OnPaint как можно скорее!"
            Invalidate();
        }

        // Подготовка к новой анимации: сброс всех счетчиков в исходное состояние
        private void StartTask(TaskMode mode)
        {
            currentTask = mode;
            timer1.Stop();

            boatX = -100; birdX = -50; birdY = 100; birdScale = 1.0f; sunY = 50;
            angle1 = 0; angle2 = 0; size1 = 150f; size2 = 50f; speed1 = 2f; speed2 = -2f;
            hexCount = 1; bgOffset = 0; wheelAngle = 0;

            if (mode != TaskMode.None) timer1.Start();
            Invalidate();
        }

        // --- ГРАФИЧЕСКИЙ ДВИЖОК (OnPaint) ---
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e); // Обязательно вызываем базовый метод
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias; // Включаем сглаживание для красоты

            // Проверка на выбранный цвет. Если цвет не выбран — выходим, чтобы не было ошибок.
            if (comboBox1.SelectedItem == null) return;

            Color c = Color.FromName(comboBox1.SelectedItem.ToString());

            // Используем using для Pen, чтобы ресурс корректно удалялся из памяти после отрисовки
            using (Pen mainPen = new Pen(c, (float)numericUpDown1.Value))
            {
                // Настройка стиля линии (пунктир или сплошная)
                if (comboBox2.SelectedIndex == 1)
                    mainPen.DashPattern = new float[] { (float)numericUpDown2.Value, (float)numericUpDown2.Value };

                // Рисуем текст "ТУСУР", если стоит галочка в CheckBox
                if (checkBox1.Checked)
                    g.DrawString("62 года ТУСУР", new Font("Arial", 16, FontStyle.Bold), Brushes.DarkBlue, 10, 150);

                // Отрисовка конкретной задачи в зависимости от активного режима
                if (currentTask == TaskMode.Task1) DrawTask1(g, mainPen);
                if (currentTask == TaskMode.Task4) DrawTask4(g, mainPen);
                if (currentTask == TaskMode.Task6) DrawTask6(g, mainPen);
                if (currentTask == TaskMode.Task13) DrawTask13(g, mainPen);
            }
        }

        // Вспомогательные пустые методы, чтобы VS не ругалась на события в дизайнере
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void numericUpDown2_ValueChanged(object sender, EventArgs e) { }
        private void numericUpDown1_ValueChanged(object sender, EventArgs e) { }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e) { }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void checkBox1_CheckedChanged(object sender, EventArgs e) { }

        // --- МЕТОДЫ ОТРИСОВКИ ФИГУР ---

        private void DrawBird(Graphics g, float x, float y, float scale)
        {
            if (scale <= 0) return;
            var state = g.Save(); // Сохраняем состояние холста
            g.TranslateTransform(x, y); // Перемещаем "центр мира" в координаты птицы
            g.ScaleTransform(scale, scale); // Уменьшаем птицу (эффект удаления)
            Pen birdPen = new Pen(Color.Black, 2);
            g.DrawArc(birdPen, -20, -10, 20, 20, 180, 140); // Левое крыло
            g.DrawArc(birdPen, 0, -10, 20, 20, 220, 140);  // Правое крыло
            g.Restore(state); // Возвращаем холст в исходное состояние
        }

        private void DrawTask1(Graphics g, Pen pen)
        {
            // Фон: небо и море
            g.FillRectangle(Brushes.Coral, 0, 0, ClientSize.Width, 300);
            g.FillEllipse(Brushes.Gold, 400, sunY + 50, 100, 100);
            g.FillRectangle(Brushes.SteelBlue, 0, 300, ClientSize.Width, ClientSize.Height);

            // Отрисовка лодки
            var state = g.Save();
            g.TranslateTransform(boatX, 260); // Лодка плывет по X
            // Корпус
            g.FillPolygon(Brushes.SaddleBrown, new PointF[] { new PointF(0, 50), new PointF(100, 50), new PointF(80, 80), new PointF(20, 80) });
            // Мачта и парус
            g.DrawLine(pen, 50, 50, 50, -50);
            g.FillPolygon(Brushes.White, new PointF[] { new PointF(50, -50), new PointF(50, 40), new PointF(100, 40) });
            g.Restore(state);

            DrawBird(g, birdX, birdY, birdScale); // Рисуем чайку
        }

        private void DrawTask4(Graphics g, Pen pen)
        {
            // Центрируем холст для вращения фигур вокруг центра
            g.TranslateTransform(ClientSize.Width / 2, ClientSize.Height / 2 + 50);

            // Первый треугольник
            var state = g.Save();
            g.RotateTransform(angle1);
            DrawPolygon(g, pen, 3, size1);
            g.Restore(state);

            // Второй треугольник (вращается в другую сторону)
            state = g.Save();
            g.RotateTransform(angle2);
            DrawPolygon(g, Pens.DarkCyan, 3, size2);
            g.Restore(state);
        }

        private void DrawTask6(Graphics g, Pen pen)
        {
            g.TranslateTransform(ClientSize.Width / 2, ClientSize.Height / 2 + 50);
            float.TryParse(textBox1.Text, out float angleB);
            Random rnd = new Random(123); // Зерно (seed) зафиксировано, чтобы цвета не мерцали хаотично

            for (int i = 0; i < hexCount; i++)
            {
                var state = g.Save();
                g.RotateTransform(i * angleB);
                using (Pen p = new Pen(Color.FromArgb(rnd.Next(100, 255), rnd.Next(100, 255), rnd.Next(100, 255)), pen.Width))
                {
                    if (comboBox2.SelectedIndex == 1)
                        p.DashPattern = new float[] { (float)numericUpDown2.Value, (float)numericUpDown2.Value };

                    DrawPolygon(g, p, 6, 10 + i * 8);
                }
                g.Restore(state);
            }
        }

        private void DrawTask13(Graphics g, Pen pen)
        {
            int centerY = ClientSize.Height / 2 + 100;

            // 1. Реалистичные рельсы и шпалы
            g.FillRectangle(Brushes.Gray, 0, centerY + 45, ClientSize.Width, 12);
            for (int i = -100; i < ClientSize.Width + 100; i += 50)
            {
                float xShpala = i + (bgOffset % 50); // Иллюзия движения за счет смещения
                g.FillRectangle(Brushes.SaddleBrown, xShpala, centerY + 48, 25, 8);
                g.FillRectangle(Brushes.Black, xShpala, centerY + 48, 25, 2);
            }
            g.DrawLine(new Pen(Color.Silver, 3), 0, centerY + 46, ClientSize.Width, centerY + 46);

            // 2. ВАГОН
            int wagonX = 50;
            g.FillRectangle(Brushes.DarkOliveGreen, wagonX, centerY - 80, 160, 100);
            g.FillRectangle(Brushes.LightSkyBlue, wagonX + 20, centerY - 60, 40, 40);
            g.FillRectangle(Brushes.LightSkyBlue, wagonX + 100, centerY - 60, 40, 40);
            g.DrawRectangle(Pens.Black, wagonX, centerY - 80, 160, 100);

            // 3. СЦЕПКА
            g.DrawLine(new Pen(Color.Black, 6), wagonX + 160, centerY + 10, wagonX + 190, centerY + 10);

            // 4. КАБИНА (Машинист сидит здесь)
            int cabinX = wagonX + 190;
            g.FillRectangle(Brushes.DarkRed, cabinX, centerY - 110, 80, 130);
            g.FillRectangle(Brushes.LightSkyBlue, cabinX + 40, centerY - 90, 30, 40);
            g.DrawRectangle(Pens.Black, cabinX, centerY - 110, 80, 130);

            // 5. КОТЕЛ (Передняя часть локомотива)
            int boilerX = cabinX + 80;
            g.FillRectangle(Brushes.Firebrick, boilerX, centerY - 60, 140, 80);
            g.DrawRectangle(Pens.Black, boilerX, centerY - 60, 140, 80);

            // 6. ТРУБА И ДЫМ
            g.FillRectangle(Brushes.Black, boilerX + 100, centerY - 95, 20, 40);
            if (wheelAngle % 60 < 30) // Анимация "пыхтения" дыма
                g.FillEllipse(Brushes.LightGray, boilerX + 90, centerY - 130, 40, 20);

            // 7. КОЛЕСА
            DrawWheel(g, wagonX + 40, centerY + 25, wheelAngle);
            DrawWheel(g, wagonX + 120, centerY + 25, wheelAngle);
            DrawWheel(g, cabinX + 40, centerY + 25, wheelAngle);
            DrawWheel(g, boilerX + 30, centerY + 25, wheelAngle);
            DrawWheel(g, boilerX + 100, centerY + 25, wheelAngle);
        }

        // Универсальный метод для рисования правильных многоугольников
        private void DrawPolygon(Graphics g, Pen p, int sides, float radius)
        {
            PointF[] pts = new PointF[sides];
            for (int i = 0; i < sides; i++)
            {
                // Рассчитываем координаты каждой вершины через синус и косинус
                double rad = (i * 360f / sides - 90) * Math.PI / 180;
                pts[i] = new PointF((float)(radius * Math.Cos(rad)), (float)(radius * Math.Sin(rad)));
            }
            g.DrawPolygon(p, pts);
        }

        // Рисуем колесо с перекрестием, чтобы было видно вращение
        private void DrawWheel(Graphics g, float x, float y, float angle)
        {
            g.FillEllipse(Brushes.Black, x - 30, y - 30, 60, 60); // Основная шина
            var state = g.Save();
            g.TranslateTransform(x, y);
            g.RotateTransform(angle); // Вращаем перекрестие внутри колеса
            g.DrawLine(Pens.White, -25, 0, 25, 0);
            g.DrawLine(Pens.White, 0, -25, 0, 25);
            g.Restore(state);
        }
    }
}