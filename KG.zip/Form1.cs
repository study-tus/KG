﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        const int MaxN = 10;
        int n = 3;
        int m = 3;
        int c = 1;
        private int n1 = 0, m1 = 0; // размеры Matr1
        private int n2 = 0, m2 = 0; // размеры Matr2
        TextBox[,] MatrText = null;
        double[,] Matr1 = new double[MaxN, MaxN];
        double[,] Matr2 = new double[MaxN, MaxN];
        double[,] Matr3 = new double[MaxN, MaxN];
        bool f1;
        bool f2;
        int dx = 40, dy = 20;
        Form2
        form2 = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "") return;
            c = int.Parse(textBox2.Text);
            if (!(f1 == true)) return;
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                {
                    Matr3[j, i] = 0;
                    Matr3[j, i] = Matr3[j, i] + Matr1[j, i] * c;
                }
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                {
                    // 3.1. Порядок табуляции
                    MatrText[i, j].TabIndex = i * n + j + 1;
                    // 3.2. Перевести число в строку
                    MatrText[i, j].Text = Matr3[i, j].ToString();
                }
            // 4. Вывод формы
            form2.ShowDialog();
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int nn))
            {
                if (nn != n)
                {
                    f1 = f2 = false;
                }
            }
            else
            {
                //возвращение курсора
                textBox1.Text = n.ToString();
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox3.Text)) return;

            int new_n = int.Parse(textBox1.Text);
            int new_m = int.Parse(textBox3.Text);

            // Скрыть ВСЕ поля ввода
            for (int i = 0; i < MatrText.GetLength(0); i++)
                for (int j = 0; j < MatrText.GetLength(1); j++)
                    MatrText[i, j].Visible = false;

            // Подготовка полей: загрузка старых данных ИЛИ нули
            if (f2 && new_n == n2 && new_m == m2)
            {
                // Размеры совпадают — показываем сохранённую матрицу для редактирования
                for (int i = 0; i < new_n; i++)
                    for (int j = 0; j < new_m; j++)
                    {
                        MatrText[i, j].Text = Matr2[i, j].ToString("G");
                        MatrText[i, j].Visible = true;
                        MatrText[i, j].TabIndex = i * new_n + j + 1;
                    }
            }
            else
            {
                // Размеры изменились — чистые поля для новой матрицы
                for (int i = 0; i < new_n; i++)
                    for (int j = 0; j < new_m; j++)
                    {
                        MatrText[i, j].Text = "0";
                        MatrText[i, j].Visible = true;
                        MatrText[i, j].TabIndex = i * new_n + j + 1;
                    }
            }

            // Настройка формы ввода
            form2.Width = 10 + new_n * dx + 20;
            form2.Height = 10 + new_m * dy + form2.button1.Height + 50;
            form2.button1.Left = 10;
            form2.button1.Top = 10 + new_m * dy + 10;
            form2.button1.Width = form2.Width - 30;

            if (form2.ShowDialog() == DialogResult.OK)
            {
                // При изменении размеров — переинициализируем массив
                if (new_n != n2 || new_m != m2)
                    Matr2 = new double[new_n, new_m];

                // Сохраняем данные
                for (int i = 0; i < new_n; i++)
                    for (int j = 0; j < new_m; j++)
                        Matr2[i, j] = double.TryParse(MatrText[i, j].Text, out double val) ? val : 0;

                // Обновляем состояние
                n2 = new_n; m2 = new_m;
                f2 = true;
                n = new_n; m = new_m; // глобальные размеры обновляем ТОЛЬКО после подтверждения
                label3.Text = "true";
            }
            // При отмене — ничего не меняем: флаги, данные и глобальные n/m остаются прежними
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox3.Text)) return;

            int new_n = int.Parse(textBox1.Text);
            int new_m = int.Parse(textBox3.Text);

            // Скрыть ВСЕ поля ввода
            for (int i = 0; i < MatrText.GetLength(0); i++)
                for (int j = 0; j < MatrText.GetLength(1); j++)
                    MatrText[i, j].Visible = false;

            // Подготовка полей: загрузка старых данных ИЛИ нули
            if (f1 && new_n == n1 && new_m == m1)
            {
                // Размеры совпадают — показываем сохранённую матрицу для редактирования
                for (int i = 0; i < new_n; i++)
                    for (int j = 0; j < new_m; j++)
                    {
                        MatrText[i, j].Text = Matr1[i, j].ToString("G");
                        MatrText[i, j].Visible = true;
                        MatrText[i, j].TabIndex = i * new_n + j + 1;
                    }
            }
            else
            {
                // Размеры изменились — чистые поля для новой матрицы
                for (int i = 0; i < new_n; i++)
                    for (int j = 0; j < new_m; j++)
                    {
                        MatrText[i, j].Text = "0";
                        MatrText[i, j].Visible = true;
                        MatrText[i, j].TabIndex = i * new_n + j + 1;
                    }
            }

            // Настройка формы ввода
            form2.Width = 10 + new_n * dx + 20;
            form2.Height = 10 + new_m * dy + form2.button1.Height + 50;
            form2.button1.Left = 10;
            form2.button1.Top = 10 + new_m * dy + 10;
            form2.button1.Width = form2.Width - 30;

            if (form2.ShowDialog() == DialogResult.OK)
            {
                // При изменении размеров — переинициализируем массив
                if (new_n != n1 || new_m != m1)
                    Matr1 = new double[new_n, new_m];

                // Сохраняем данные
                for (int i = 0; i < new_n; i++)
                    for (int j = 0; j < new_m; j++)
                        Matr1[i, j] = double.TryParse(MatrText[i, j].Text, out double val) ? val : 0;

                // Обновляем состояние
                n1 = new_n; m1 = new_m;
                f1 = true;
                n = new_n; m = new_m; // глобальные размеры обновляем ТОЛЬКО после подтверждения
                label2.Text = "true";
            }
            // При отмене — ничего не меняем: флаги, данные и глобальные n/m остаются прежними
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int rows = Matr1.GetLength(0);
            int cols = Matr1.GetLength(1);
            if ((rows != 1 && cols != 1) || (rows == 0 && cols == 0 ))
            {
                MessageBox.Show($"Обнаружена матрица [{rows}×{cols}], а не вектор.");
                return;
            }
            double r = 0;
            n = int.Parse(textBox1.Text);
            m = int.Parse(textBox3.Text);
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    r = r + Matr1[i, j] * Matr1[i, j];
            r = Math.Sqrt(r);
            MessageBox.Show($"Модуль вектора равен {r}.");
            return;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int rows1 = Matr1.GetLength(0);
            int cols1 = Matr1.GetLength(1);
            int rows2 = Matr2.GetLength(0);
            int cols2 = Matr2.GetLength(1);
            if ((rows1 != rows2 && cols1 != cols2) || (rows1 == 0 && cols1 == 0) || (rows2 == 0 && cols2 == 0))
            {
                MessageBox.Show($"Для скалярного произведения нужны 2 вектора одинакового размера!");
                return;
            }
            
            double result = 0;
            n1 = rows1;
            m1 = cols1;

            for (int i = 0; i < n1; i++)
                for (int j = 0; j < m1; j++)
                    result += Matr1[i, j] * Matr2[i, j];

            MessageBox.Show($"Скалярное произведение векторов равно {result}.");
            return;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // === ПРОВЕРКА ИНИЦИАЛИЗАЦИИ ===
            if (Matr1 == null || Matr2 == null)
            {
                MessageBox.Show("Оба вектора должны быть введены!\n" +
                                "Используйте кнопки \"Матрица 1\" и \"Матрица 2\" для ввода векторов.",
                                "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // === ВСПОМОГАТЕЛЬНАЯ ФУНКЦИЯ: извлечение вектора + определение размерности ===
            bool TryExtractVector(double[,] mat, out double[] vec, out string errorMsg)
            {
                int rows = mat.GetLength(0);
                int cols = mat.GetLength(1);

                // Проверка: должен быть вектор (строка ИЛИ столбец)
                if (rows != 1 && cols != 1)
                {
                    errorMsg = $"Обнаружена матрица [{rows}×{cols}].\n" +
                               "Вектор должен быть строкой (1×N) или столбцом (N×1).";
                    vec = null;
                    return false;
                }

                // Автоматическое определение количества компонент
                int size = rows * cols;
                vec = new double[size];
                int idx = 0;

                for (int i = 0; i < rows; i++)
                    for (int j = 0; j < cols; j++)
                        vec[idx++] = mat[i, j];

                errorMsg = null;
                return true;
            }

            // === ИЗВЛЕЧЕНИЕ ВЕКТОРОВ И ПРОВЕРКА РАЗМЕРНОСТИ ===
            if (!TryExtractVector(Matr1, out double[] a, out string err1))
            {
                MessageBox.Show($"Ошибка в первом векторе:\n{err1}", "Некорректный формат",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!TryExtractVector(Matr2, out double[] b, out string err2))
            {
                MessageBox.Show($"Ошибка во втором векторе:\n{err2}", "Некорректный формат",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Автоматическая проверка совпадения размерностей
            if (a.Length != b.Length)
            {
                MessageBox.Show(
                    $"Размерности векторов не совпадают!\n" +
                    $"Вектор A: {a.Length} компонент(ы)\n" +
                    $"Вектор B: {b.Length} компонент(ы)\n\n" +
                    "Для операции требуется одинаковое количество компонент.",
                    "Ошибка размерности", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // СТРОГАЯ ПРОВЕРКА: векторное произведение определено ТОЛЬКО в ℝ³
            if (a.Length != 3)
            {
                MessageBox.Show(
                    $"Векторное произведение определено ТОЛЬКО для трёхмерных векторов!\n\n" +
                    $"Текущая размерность: {a.Length} компонент(ы)\n\n" +
                    "Поддерживаются только векторы размером:\n" +
                    "• Строка: 1×3\n" +
                    "• Столбец: 3×1\n");
                return;
            }

            // === ВЫЧИСЛЕНИЕ (только для 3D) ===
            double[] result = new double[3];
            try
            {
                result[0] = a[1] * b[2] - a[2] * b[1]; // x (i)
                result[1] = a[2] * b[0] - a[0] * b[2]; // y (j)
                result[2] = a[0] * b[1] - a[1] * b[0]; // z (k)
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка вычисления: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // === ВЫВОД РЕЗУЛЬТАТА (вектор-столбец 3×1) ===
            // Скрыть все поля
            for (int i = 0; i < MatrText.GetLength(0); i++)
                for (int j = 0; j < MatrText.GetLength(1); j++)
                    MatrText[i, j].Visible = false;

            // Отобразить результат
            for (int i = 0; i < 3; i++)
            {
                MatrText[i, 0].Text = result[i].ToString("G6");
                MatrText[i, 0].Visible = true;
                MatrText[i, 0].TabIndex = i + 1;
            }

            // Настройка формы вывода
            form2.Width = 40 + dx;
            form2.Height = 70 + 3 * dy + form2.button1.Height;
            form2.button1.Left = (form2.Width - form2.button1.Width) / 2;
            form2.button1.Top = 25 + 3 * dy;
            form2.button1.Width = form2.Width - 40;
            form2.button1.Text = "Закрыть";

            // Информативный заголовок
            string title = $"a × b = ({a[0]:F2}, {a[1]:F2}, {a[2]:F2}) × ({b[0]:F2}, {b[1]:F2}, {b[2]:F2})";
            string originalTitle = form2.Text;
            form2.Text = title;

            string originalBtnText = form2.button1.Text;
            try
            {
                form2.ShowDialog();
            }
            finally
            {
                // Восстановление состояния интерфейса
                form2.button1.Text = "Подтвердить";
                form2.Text = originalTitle;
                for (int i = 0; i < 3; i++)
                {
                    MatrText[i, 0].BackColor = System.Drawing.Color.White;
                    MatrText[i, 0].ReadOnly = false;
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int rows = Matr1.GetLength(0);
            int cols = Matr1.GetLength(1);
            if (rows == 0 || cols == 0)
            {
                MessageBox.Show("Матрица имеет некорректный размер!");
                return;
            }

            n = int.Parse(textBox1.Text);
            m = int.Parse(textBox3.Text);

            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                {
                    Matr3[j, i] = 0;
                    Matr3[j, i] = Matr1[i, j];
                }

            int maxDisplayRows = MatrText.GetLength(0);
            int maxDisplayCols = MatrText.GetLength(1);

            int displayRows = Math.Min(rows, maxDisplayRows);
            int displayCols = Math.Min(cols, maxDisplayCols);
            
            for (int i = 0; i < maxDisplayRows; i++)
                for (int j = 0; j < maxDisplayCols; j++)
                    MatrText[i, j].Visible = false;

            for (int i = 0; i < displayRows; i++)
            {
                for (int j = 0; j < displayCols; j++)
                {
                    MatrText[j, i].Text = Matr3[j, i].ToString();
                    MatrText[j, i].Visible = true;
                    MatrText[j, i].TabIndex = i * displayCols + j + 1;
                }
            }

            int padding = 25;
            form2.Width = padding + displayCols * dx + 20;
            form2.Height = padding + displayRows * dy + form2.button1.Height + 40;

            // Центрируем кнопку
            form2.button1.Left = (form2.Width - form2.button1.Width) / 2;
            form2.button1.Top = 15 + displayRows * dy;
            form2.button1.Text = "Закрыть";

            // Сохраняем оригинальное состояние
            string originalBtnText = form2.button1.Text;
            string originalFormTitle = form2.Text;

            form2.ShowDialog();
        }


        private void button8_Click(object sender, EventArgs e)
        {
            // === ПРОВЕРКА ИНИЦИАЛИЗАЦИИ ===
            if (Matr1 == null || Matr2 == null)
            {
                MessageBox.Show("Матрица или вектор не инициализированы!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // === ПОЛУЧЕНИЕ РАЗМЕРОВ ===
            int matRows = Matr1.GetLength(0);
            int matCols = Matr1.GetLength(1);

            // Проверка корректности матрицы
            if (matRows <= 0 || matCols <= 0)
            {
                MessageBox.Show("Матрица имеет некорректный размер!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // === ПРОВЕРКА РАЗМЕРА ВЕКТОРА (ТОЛЬКО СТОЛБЕЦ) ===
            if (Matr2.Rank != 2)
            {
                MessageBox.Show("Вектор должен быть двумерным массивом!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // === ПРОВЕРКА ВЕКТОРА-СТРОКИ (1 × matCols) ===
            if (Matr2.Rank != 2 || Matr2.GetLength(0) != 1 || Matr2.GetLength(1) != matCols)
            {
                MessageBox.Show(
                    $"Для умножения матрицы [{matRows}×{matCols}] требуется вектор-строка размером [1×{matCols}].\n" +
                    $"Фактический размер вектора: [{Matr2.GetLength(0)}×{Matr2.GetLength(1)}].\n\n" +
                    "Введите вектор как ОДНУ СТРОКУ (количество строк = 1, столбцов = {matCols}).",
                    "Ошибка размерности", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // === УМНОЖЕНИЕ ===
            double[] result = new double[matRows];
            try
            {
                for (int i = 0; i < matRows; i++)
                    for (int j = 0; j < matCols; j++)
                        Matr3[j, i] = Matr1[i, j];

                for (int i = 0; i < matCols; i++)
                {
                    double sum = 0;
                    for (int j = 0; j < matCols; j++)
                    {
                        // Берём элемент вектора из СТРОКИ: Matr2[0, j]
                        sum += Matr3[i, j] * Matr2[0, j];
                    }
                    result[i] = sum;
                }
            }
            catch (IndexOutOfRangeException ex)
            {
                MessageBox.Show($"Ошибка при вычислении: {ex.Message}\n" +
                                "Проверьте корректность данных в матрице и векторе.",
                                "Ошибка вычисления", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // === ПОДГОТОВКА ВЫВОДА ===
            // Скрываем все поля ввода
            for (int i = 0; i < MatrText.GetLength(0); i++)
                for (int j = 0; j < MatrText.GetLength(1); j++)
                    MatrText[i, j].Visible = false;

            // Отображаем результат как столбец
            int displayRows = Math.Min(matRows, MatrText.GetLength(0));
            for (int i = 0; i < displayRows; i++)
            {
                MatrText[0, i].Text = result[i].ToString();
                MatrText[0, i].Visible = true;
                MatrText[0, i].TabIndex = i + 1;
            }

            // === НАСТРОЙКА ФОРМЫ ВЫВОДА ===
            form2.Width = 10 + dx + 20;
            form2.Height = 10 + displayRows * dy + form2.button1.Height + 50;
            form2.button1.Left = 10;
            form2.button1.Top = 10 + displayRows * dy + 10;
            form2.button1.Width = form2.Width - 30;
            form2.button1.Text = "Закрыть"; // Явное указание действия

            // Сохраняем исходный текст кнопки для восстановления
            string originalButtonText = form2.button1.Text;
            try
            {
                if (form2.ShowDialog() == DialogResult.OK)
                {
                    // При необходимости: обработка подтверждения
                }
            }
            finally
            {
                // Восстанавливаем состояние кнопки для будущих вызовов ввода
                form2.button1.Text = "Подтвердить";
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            int cc;
            cc = Int16.Parse(textBox2.Text);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_Leave(object sender, EventArgs e)
        {
            int mm;
            mm = Int16.Parse(textBox3.Text);
            if (mm != m)
            {
                f1 = f2 = false;
            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                {
                    // 3.1. Порядок табуляции
                    MatrText[i, j].TabIndex = i * n + j + 1;
                    // 3.2. Сделать ячейку видимой
                    MatrText[i, j].Visible = false;
                }
        }

        private void textBox3_Enter(object sender, EventArgs e)
        {
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                {
                    // 3.1. Порядок табуляции
                    MatrText[i, j].TabIndex = i * n + j + 1;
                    // 3.2. Сделать ячейку видимой
                    MatrText[i, j].Visible = false;
                }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "";
            f1 = f2 = false; // матрицы еще не заполнены
            label2.Text = "false";
            label3.Text = "false";
            // ІІ. Выделение памяти и настройка MatrText
            int i, j;
            // 1. Выделение памяти для формы Form2
            form2 = new Form2();
            // 2. Выделение памяти под самую матрицу
            MatrText = new TextBox[MaxN, MaxN];
            // 3. Выделение памяти для каждой ячейки матрицы и ее настройка
            for (i = 0; i < MaxN; i++)
                for (j = 0; j < MaxN; j++)
                {
                    // 3.1. Выделить память
                    MatrText[i, j] = new TextBox();
                    // 3.2. Обнулить эту ячейку
                    MatrText[i, j].Text = "0";
                    // 3.3. Установить позицию ячейки в форме Form2
                    MatrText[i, j].Location = new System.Drawing.Point(10 + i * dx, 10 + j * dy);
                    // 3.4. Установить размер ячейки
                    MatrText[i, j].Size = new System.Drawing.Size(dx, dy);
                    // 3.5. Пока что спрятать ячейку
                    MatrText[i, j].Visible = false;
                    // 3.6. Добавить MatrText[i,j] в форму form2
                    form2.Controls.Add(MatrText[i, j]);
                }
        }
    }
}