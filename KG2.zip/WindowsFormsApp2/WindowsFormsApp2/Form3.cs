﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        // Кнопка для Лабы 1 (Матрицы)
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 newForm = new Form1();
            newForm.Show();
        }

        // Кнопка для Лабы 2 (Графика)
        private void button2_Click(object sender, EventArgs e)
        {
            Form4 formLab2 = new Form4();
            formLab2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Здесь будет Лаба 3
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Здесь будет Лаба 4
        }
    }
}