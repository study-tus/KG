﻿namespace WindowsFormsApp7
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(723, 818);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(782, 47);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(272, 59);
            this.button1.TabIndex = 1;
            this.button1.Text = "Нарисовать оси";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(782, 140);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(271, 61);
            this.button2.TabIndex = 2;
            this.button2.Text = "Нарисовать фигуру";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(782, 388);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(270, 67);
            this.button3.TabIndex = 4;
            this.button3.Text = "По оси OX Вправо";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button4_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(782, 485);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(271, 58);
            this.button4.TabIndex = 5;
            this.button4.Text = "По оси OX влево";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(782, 575);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(269, 61);
            this.button5.TabIndex = 6;
            this.button5.Text = "По оси OY вниз";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(782, 655);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(268, 59);
            this.button6.TabIndex = 7;
            this.button6.Text = "По оси OY вверх";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(780, 755);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(163, 68);
            this.button7.TabIndex = 8;
            this.button7.Text = "СТАРТ";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.btnContinuous_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Impact", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(810, 314);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(240, 61);
            this.label2.TabIndex = 10;
            this.label2.Text = "СДВИГ";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(790, 234);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(259, 70);
            this.button8.TabIndex = 11;
            this.button8.Text = "Очистить";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(1155, 111);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(229, 57);
            this.button9.TabIndex = 12;
            this.button9.Text = "поворот 15 град.";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Impact", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1176, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 53);
            this.label1.TabIndex = 13;
            this.label1.Text = "ПОВОРОТ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(1157, 291);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(227, 55);
            this.button10.TabIndex = 14;
            this.button10.Text = "Увеличить x1.1";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Impact", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(1172, 205);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(193, 53);
            this.label3.TabIndex = 15;
            this.label3.Text = "Масштаб";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(1157, 379);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(228, 54);
            this.button11.TabIndex = 16;
            this.button11.Text = "Уменьшить х0.9";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Impact", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(1172, 478);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(231, 53);
            this.label4.TabIndex = 17;
            this.label4.Text = "Отражение";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(1157, 565);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(226, 45);
            this.button12.TabIndex = 18;
            this.button12.Text = "Отразить по Y";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(1160, 639);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(222, 47);
            this.button13.TabIndex = 19;
            this.button13.Text = "Отразить по X";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1435, 836);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Лабораторная работа";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
    }
}