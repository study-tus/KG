﻿using System;
using System.Drawing;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        double[,] fig = new double[8, 3]; // Матрица тела 
        double[,] osi = new double[4, 3]; // Матрица осей
        double[,] matr_preob = new double[3, 3]; // Матрица преобразований

        double k, l;           // Координаты центра сдвига
        double angle = 0;      // Угол поворота 
        double scale = 1.0;    // Масштаб
        double reflect = 1.0;  // Отражение (1 или -1)
        double reflectX = 1.0;
        bool f = true;         // Флаг для таймера

        public Form1()
        {
            InitializeComponent();
        }

        //Рисуем фигуру
        private void Init_figure()
        {
            // Меняем размер массива, так как теперь точек всего 4
            fig = new double[4, 3];

            // Левый треугольник
            fig[0, 0] = -50; fig[0, 1] = -50; fig[0, 2] = 1; // Верхний левый угол
            fig[1, 0] = -50; fig[1, 1] = 50; fig[1, 2] = 1; // Нижний левый угол

            // Правый треугольник
            fig[2, 0] = 50; fig[2, 1] = -10; fig[2, 2] = 1; // Верхний правый угол
            fig[3, 0] = 50; fig[3, 1] = 10; fig[3, 2] = 1; // Нижний правый угол
        }

        private void Init_osi()
        {
            osi[0, 0] = -300; osi[0, 1] = 0; osi[0, 2] = 1;
            osi[1, 0] = 300; osi[1, 1] = 0; osi[1, 2] = 1;
            osi[2, 0] = 0; osi[2, 1] = 300; osi[2, 2] = 1;
            osi[3, 0] = 0; osi[3, 1] = -300; osi[3, 2] = 1;
        }

        // Универсальная матрица аффинных преобразований
        private void Init_matr_preob(double k1, double l1)
        {
            // Строка 1: Влияние на X 
            matr_preob[0, 0] = Math.Cos(angle) * scale * reflectX;
            matr_preob[0, 1] = Math.Sin(angle) * scale * reflect;
            matr_preob[0, 2] = 0;

            // Строка 2: Влияние на Y
            matr_preob[1, 0] = -Math.Sin(angle) * scale * reflectX;
            matr_preob[1, 1] = Math.Cos(angle) * scale * reflect;
            matr_preob[1, 2] = 0;

            // Строка 3: Смещение в центр (k, l)
            matr_preob[2, 0] = k1;
            matr_preob[2, 1] = l1;
            matr_preob[2, 2] = 1;
        }

        //Умножение
        private double[,] Multiply_matr(double[,] a, double[,] b)
        {
            int n = a.GetLength(0);
            int m = b.GetLength(1);
            double[,] r = new double[n, m];

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    r[i, j] = 0;
                    for (int ii = 0; ii < a.GetLength(1); ii++)
                    {
                        r[i, j] += a[i, ii] * b[ii, j];
                    }
                }
            }
            return r;
        }

        //ФУНКЦИИ ОТРИСОВКИ

        private void Draw_osi()
        {
            Init_osi();

            // Вычисляем центр один раз локально, не используя глобальные k и l
            float centerX = pictureBox1.Width / 2f;
            float centerY = pictureBox1.Height / 2f;

            double[,] static_center_matr = new double[3, 3] {
        { 1, 0, 0 },
        { 0, 1, 0 },
        { centerX, centerY, 1 }
    };

            double[,] osi1 = Multiply_matr(osi, static_center_matr);

            Graphics g = Graphics.FromHwnd(pictureBox1.Handle);
            g.Clear(Color.White);

            Pen myPen = new Pen(Color.Red, 1);
            // Рисуем оси
            g.DrawLine(myPen, (float)osi1[0, 0], (float)osi1[0, 1], (float)osi1[1, 0], (float)osi1[1, 1]);
            g.DrawLine(myPen, (float)osi1[2, 0], (float)osi1[2, 1], (float)osi1[3, 0], (float)osi1[3, 1]);

            myPen.Dispose();
            g.Dispose();
        }

        private void Draw_Figure()
        {
            Draw_osi(); 

            Init_figure();
            Init_matr_preob(k, l);
            double[,] fig1 = Multiply_matr(fig, matr_preob);

            Graphics g = Graphics.FromHwnd(pictureBox1.Handle);
            Pen myPen = new Pen(Color.Blue, 3); // Синий контур, толщина 3

            // Рисуем контур скобы (8 линий)
            int pointsCount = fig1.GetLength(0);
            for (int i = 0; i < pointsCount; i++)
            {
                int next = (i + 1) % pointsCount; // Замыкаем последнюю точку на первую
                g.DrawLine(myPen, (float)fig1[i, 0], (float)fig1[i, 1], (float)fig1[next, 0], (float)fig1[next, 1]);
            }

            myPen.Dispose();
            g.Dispose();
        }

        //ОБРАБОТЧИКИ КНОПОК

        // Оси
        private void button1_Click(object sender, EventArgs e)
        {
            k = pictureBox1.Width / 2;
            l = pictureBox1.Height / 2;
            Draw_osi();
        }

        // Фигура
        private void button2_Click(object sender, EventArgs e)
        {
            k = pictureBox1.Width / 2;
            l = pictureBox1.Height / 2;
            angle = 0; scale = 1; reflect = 1; // Сбрасываем трансформации
            Draw_Figure();
        }

        // Вправо
        private void button4_Click(object sender, EventArgs e)
        {
            k += 10;
            Draw_Figure();
        }

        // Влево
        private void btnLeft_Click(object sender, EventArgs e)
        {
            k -= 10;
            Draw_Figure();
        }

        // Вверх
        private void btnUp_Click(object sender, EventArgs e)
        {
            l -= 10; 
            Draw_Figure();
        }

        // Вниз
        private void btnDown_Click(object sender, EventArgs e)
        {
            l += 10;
            Draw_Figure();
        }

        // Старт/Стоп
        private void btnContinuous_Click(object sender, EventArgs e)
        {
            timer1.Interval = 100;

            Button btn = sender as Button;

            btn.Text = "Стоп";
            if (f == true)
                timer1.Start();
            else
            {
                timer1.Stop();
                btn.Text = "Старт";
            }
            f = !f;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Graphics g = Graphics.FromHwnd(pictureBox1.Handle);
            g.Clear(pictureBox1.BackColor);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            angle += 15 * Math.PI / 180; // Перевод в радианы
            Draw_Figure();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            scale *= 1.1;
            Draw_Figure();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            reflect *= -1;
            Draw_Figure();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            reflectX *= -1;
            Draw_Figure();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            scale *= 0.9;
            Draw_Figure();
        }

        // Таймер (Анимация движения по диагонали с вращением)
        private void timer1_Tick(object sender, EventArgs e)
        {
            k++; 
            Draw_Figure();
            Thread.Sleep(100);
        }
    }
}