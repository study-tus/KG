﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Lab3D
{
    // Класс для представления трехмерной точки
    public class Point3D
    {
        public double X;
        public double Y;
        public double Z;

        public Point3D(double x, double y, double z)
        {
            X = x;
            Y = y;
            Z = z;
        }
    }

    public partial class Form1 : Form
    {
        // Координаты 5 вершин объемного шестигранника
        Point3D[] vertices = {
            new Point3D(0, 0, 1.5),   // 0 (Передняя центральная вершина)
            new Point3D(0, 1, 0),     // 1 (Верхняя точка)
            new Point3D(1, 0, 0.5),   // 2 (Правая точка)
            new Point3D(0, -1, 0),    // 3 (Нижняя точка)
            new Point3D(-1, 0, 0.5)   // 4 (Левая точка)
        };

        // Индексы вершин треугольных граней 
        int[][] faces = {
            new int[] {0, 2, 1}, // Передняя верхняя правая
            new int[] {0, 3, 2}, // Передняя нижняя правая
            new int[] {0, 4, 3}, // Передняя нижняя левая
            new int[] {0, 1, 4}, // Передняя верхняя левая
            new int[] {1, 3, 4}, // Задняя левая
            new int[] {1, 2, 3}  // Задняя правая
        };

        Point3D[] osVert = {
            new Point3D(0, 0, 0), new Point3D(2.0, 0, 0),
            new Point3D(0, 0, 0), new Point3D(0, 2.0, 0),
            new Point3D(0, 0, 0), new Point3D(0, 0, 2.0)
        };

        double tx = 0, ty = 0, tz = 0;
        double sx = 80, sy = 80, sz = 80;
        double angX = 20, angY = 30, angZ = 0;
        double speedY = 2;
        bool isPlay = true;
        Timer mainTimer;

        public Form1()
        {
            this.Text = "Лабораторная работа 3D - Алгоритм Робертса";
            this.Width = 800;
            this.Height = 600;
            this.DoubleBuffered = true;
            this.StartPosition = FormStartPosition.CenterScreen;

            mainTimer = new Timer();
            mainTimer.Interval = 30;
            mainTimer.Tick += MainTimer_Tick;
            mainTimer.Start();

            this.KeyDown += Form1_KeyDown;
        }

        private void MainTimer_Tick(object sender, EventArgs e)
        {
            if (isPlay)
            {
                angY += speedY;
                if (angY >= 360) angY -= 360;
                if (angY < 0) angY += 360;
            }
            this.Invalidate();
        }

        double[,] UmnozhMatric(double[,] A, double[,] B)
        {
            double[,] C = new double[4, 4];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    C[i, j] = 0;
                    for (int k = 0; k < 4; k++)
                    {
                        C[i, j] += A[i, k] * B[k, j];
                    }
                }
            }
            return C;
        }

        double[,] GetMatrica()
        {
            double[,] mat = new double[4, 4];
            for (int i = 0; i < 4; i++) mat[i, i] = 1;

            double[,] mScale = new double[4, 4];
            mScale[0, 0] = sx; mScale[1, 1] = sy; mScale[2, 2] = sz; mScale[3, 3] = 1;
            mat = UmnozhMatric(mat, mScale);

            double rx = angX * Math.PI / 180.0;
            double[,] mRotX = new double[4, 4];
            mRotX[0, 0] = 1; mRotX[3, 3] = 1;
            mRotX[1, 1] = Math.Cos(rx); mRotX[1, 2] = Math.Sin(rx);
            mRotX[2, 1] = -Math.Sin(rx); mRotX[2, 2] = Math.Cos(rx);
            mat = UmnozhMatric(mat, mRotX);

            double ry = angY * Math.PI / 180.0;
            double[,] mRotY = new double[4, 4];
            mRotY[1, 1] = 1; mRotY[3, 3] = 1;
            mRotY[0, 0] = Math.Cos(ry); mRotY[0, 2] = -Math.Sin(ry);
            mRotY[2, 0] = Math.Sin(ry); mRotY[2, 2] = Math.Cos(ry);
            mat = UmnozhMatric(mat, mRotY);

            double rz = angZ * Math.PI / 180.0;
            double[,] mRotZ = new double[4, 4];
            mRotZ[2, 2] = 1; mRotZ[3, 3] = 1;
            mRotZ[0, 0] = Math.Cos(rz); mRotZ[0, 1] = Math.Sin(rz);
            mRotZ[1, 0] = -Math.Sin(rz); mRotZ[1, 1] = Math.Cos(rz);
            mat = UmnozhMatric(mat, mRotZ);

            double[,] mTrans = new double[4, 4];
            for (int i = 0; i < 4; i++) mTrans[i, i] = 1;
            mTrans[3, 0] = tx;
            mTrans[3, 1] = ty;
            mTrans[3, 2] = tz;
            mat = UmnozhMatric(mat, mTrans);

            return mat;
        }

        Point3D TransformTochka(Point3D p, double[,] m)
        {
            double x = p.X * m[0, 0] + p.Y * m[1, 0] + p.Z * m[2, 0] + m[3, 0];
            double y = p.X * m[0, 1] + p.Y * m[1, 1] + p.Z * m[2, 1] + m[3, 1];
            double z = p.X * m[0, 2] + p.Y * m[1, 2] + p.Z * m[2, 2] + m[3, 2];
            return new Point3D(x, y, z);
        }

        PointF Proekciya(Point3D p)
        {
            float cx = this.ClientSize.Width / 2f;
            float cy = this.ClientSize.Height / 2f;
            return new PointF((float)(cx + p.X), (float)(cy - p.Y));
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Заполнение фона
            using (LinearGradientBrush bg = new LinearGradientBrush(this.ClientRectangle, Color.FromArgb(20, 20, 25), Color.Black, 90F))
            {
                g.FillRectangle(bg, this.ClientRectangle);
            }

            double[,] mat = GetMatrica();

            Point3D[] tOs = new Point3D[osVert.Length];
            for (int i = 0; i < osVert.Length; i++)
                tOs[i] = TransformTochka(osVert[i], mat);

            using (Pen penX = new Pen(Color.FromArgb(255, 70, 70), 2))
            using (Pen penY = new Pen(Color.FromArgb(70, 255, 70), 2))
            using (Pen penZ = new Pen(Color.FromArgb(50, 160, 255), 2))
            using (var arrow = new AdjustableArrowCap(4, 6, true))
            {
                penX.CustomEndCap = arrow; penY.CustomEndCap = arrow; penZ.CustomEndCap = arrow;

                g.DrawLine(penX, Proekciya(tOs[0]), Proekciya(tOs[1]));
                g.DrawLine(penY, Proekciya(tOs[2]), Proekciya(tOs[3]));
                g.DrawLine(penZ, Proekciya(tOs[4]), Proekciya(tOs[5]));

                using (Font fAx = new Font("Segoe UI", 10, FontStyle.Bold))
                {
                    g.DrawString("X", fAx, Brushes.LightSalmon, Proekciya(tOs[1]).X + 5, Proekciya(tOs[1]).Y - 5);
                    g.DrawString("Y", fAx, Brushes.LightGreen, Proekciya(tOs[3]).X - 5, Proekciya(tOs[3]).Y - 18);
                    g.DrawString("Z", fAx, Brushes.LightBlue, Proekciya(tOs[5]).X + 5, Proekciya(tOs[5]).Y + 5);
                }
            }

            Point3D[] wPts = new Point3D[vertices.Length];
            for (int i = 0; i < vertices.Length; i++)
            {
                wPts[i] = TransformTochka(vertices[i], mat);
            }

            // Вычисление барицентра многогранника (W)
            double wX = 0, wY = 0, wZ = 0;
            for (int i = 0; i < wPts.Length; i++)
            {
                wX += wPts[i].X;
                wY += wPts[i].Y;
                wZ += wPts[i].Z;
            }
            wX /= wPts.Length;
            wY /= wPts.Length;
            wZ /= wPts.Length;

            // Координаты точки наблюдения P (ортогональная проекция вдоль оси Z)
            double pX = 0, pY = 0, pZ = 10000;

            // Расчет видимости и отрисовка граней по алгоритму Робертса
            for (int i = 0; i < faces.Length; i++)
            {
                Point3D v1 = wPts[faces[i][0]];
                Point3D v2 = wPts[faces[i][1]];
                Point3D v3 = wPts[faces[i][2]];

                // Векторы, лежащие в плоскости грани
                double vec1X = v1.X - v2.X;
                double vec1Y = v1.Y - v2.Y;
                double vec1Z = v1.Z - v2.Z;

                double vec2X = v3.X - v2.X;
                double vec2Y = v3.Y - v2.Y;
                double vec2Z = v3.Z - v2.Z;

                // Коэффициенты уравнения плоскости
                double A = vec1Y * vec2Z - vec2Y * vec1Z;
                double B = vec1Z * vec2X - vec2Z * vec1X;
                double C = vec1X * vec2Y - vec2X * vec1Y;
                double D = -(A * v1.X + B * v1.Y + C * v1.Z);

                // Коэффициент, корректирующий направление плоскости с помощью барицентра
                double m = -Math.Sign(A * wX + B * wY + C * wZ + D);
                if (m == 0) m = 1;

                A = A * m;
                B = B * m;
                C = C * m;
                D = D * m;

                // Проверка видимости относительно точки наблюдения P
                if (A * pX + B * pY + C * pZ + D > 0)
                {
                    PointF[] screenPoints = new PointF[3];
                    screenPoints[0] = Proekciya(v1);
                    screenPoints[1] = Proekciya(v2);
                    screenPoints[2] = Proekciya(v3);

                    using (Brush fBrush = new SolidBrush(Color.FromArgb(255, 0, 160, 255)))
                    {
                        g.FillPolygon(fBrush, screenPoints);
                    }
                    using (Pen ePen = new Pen(Color.Cyan, 2f))
                    {
                        g.DrawPolygon(ePen, screenPoints);
                    }
                }
            }

            for (int i = 0; i < wPts.Length; i++)
            {
                PointF sp = Proekciya(wPts[i]);
                g.FillEllipse(Brushes.White, sp.X - 3, sp.Y - 3, 6, 6);
            }

            string textPodskazka = "УПРАВЛЕНИЕ:\n" +
                                   "W / S / A / D - Перемещение по осям\n" +
                                   "Q / E - Масштабирование по X / Z \n" +
                                   "R / F - Масштабирование по Y\n" +
                                   "Пробел - Старт / Пауза анимации \n" +
                                   "Стрелки - Изменение скорости\n" +
                                   "M - Зеркальное отображение относительно плоскости XY";

            using (Font fUi = new Font("Segoe UI", 10, FontStyle.Regular))
            {
                g.DrawString(textPodskazka, fUi, Brushes.WhiteSmoke, 15, 15);
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.W) ty += 10;
            if (e.KeyCode == Keys.S) ty -= 10;
            if (e.KeyCode == Keys.A) tx -= 10;
            if (e.KeyCode == Keys.D) tx += 10;

            if (e.KeyCode == Keys.Q) { sx += 5; sz += 5; }
            if (e.KeyCode == Keys.E) { sx -= 5; sz -= 5; }
            if (e.KeyCode == Keys.R) sy += 5;
            if (e.KeyCode == Keys.F) sy -= 5;

            if (e.KeyCode == Keys.Right) speedY += 0.5;
            if (e.KeyCode == Keys.Left) speedY -= 0.5;

            if (e.KeyCode == Keys.Space) isPlay = !isPlay;

            if (e.KeyCode == Keys.M)
            {
                for (int i = 0; i < vertices.Length; i++)
                {
                    vertices[i].Z = -vertices[i].Z;
                }
            }

            this.Invalidate();
        }
    }
}