﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Numerics;

namespace Lab4WinForms
{
    public partial class Form1 : Form
    {
        // UI элементы
        private PictureBox pb;
        private ComboBox cmbTask;
        private TrackBar tbRotY, tbScale, tbOffset;
        private Timer animTimer;

        // Матрицы
        private Matrix4x4 modelMatrix = Matrix4x4.Identity;
        private Matrix4x4 viewMatrix = Matrix4x4.Identity;
        private Matrix4x4 projMatrix = Matrix4x4.Identity;
        private Matrix4x4 vpMatrix = Matrix4x4.Identity;

        // Геометрия
        private List<Vector4> vertices = new List<Vector4>();
        private List<Tuple<int, int>> edges = new List<Tuple<int, int>>();
        private List<Face> faces = new List<Face>();

        private int currentTask = 0;

        public Form1()
        {
            InitializeComponent();
            SetupUI();

            // Включаем двойную буферизацию для .NET 4.7.2
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            this.UpdateStyles();

            animTimer = new Timer { Interval = 30 };
            animTimer.Tick += (s, e) =>
            {
                tbRotY.Value = (tbRotY.Value + 1) % 360;
                pb.Invalidate();
            };

            GenerateGeometry();
        }

        private void SetupUI()
        {
            this.Text = "Лаб 4: Матричные преобразования (.NET 4.7.2)";
            this.Size = new Size(920, 680);
            this.StartPosition = FormStartPosition.CenterScreen;

            cmbTask = new ComboBox { Location = new Point(10, 10), Width = 220, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbTask.Items.AddRange(new string[] {
                "Таб 2. Вар 1: Z=sin(R)/R",
                "Таб 2. Вар 2: Z=sin²x+sin²y",
                "Таб 3. Вар 3: Шестигранник, 2 точки схода, Робертс",
                "Таб 3. Вар 11: Пятиугольная призма, Диметрия, Робертс"
            });
            cmbTask.SelectedIndex = 0;
            cmbTask.SelectedIndexChanged += (s, e) => { currentTask = cmbTask.SelectedIndex; tbOffset.Value = 0; GenerateGeometry(); };
            this.Controls.Add(cmbTask);

            tbRotY = new TrackBar { Location = new Point(10, 45), Width = 220, Minimum = 0, Maximum = 360, Value = 25, TickStyle = TickStyle.None };
            tbRotY.ValueChanged += (s, e) => pb.Invalidate();
            this.Controls.Add(tbRotY);

            tbScale = new TrackBar { Location = new Point(10, 80), Width = 220, Minimum = 20, Maximum = 250, Value = 100, TickStyle = TickStyle.None };
            tbScale.ValueChanged += (s, e) => pb.Invalidate();
            this.Controls.Add(tbScale);

            tbOffset = new TrackBar { Location = new Point(10, 115), Width = 220, Minimum = -200, Maximum = 200, Value = 0, TickStyle = TickStyle.None, Visible = false };
            tbOffset.ValueChanged += (s, e) => pb.Invalidate();
            this.Controls.Add(tbOffset);

            Button btnAnim = new Button { Text = "Авто-вращение", Location = new Point(10, 150), Width = 220 };
            btnAnim.Click += (s, e) => { if (animTimer.Enabled) animTimer.Stop(); else animTimer.Start(); };
            this.Controls.Add(btnAnim);

            pb = new PictureBox { Location = new Point(240, 10), Size = new Size(660, 640), BackColor = Color.White };
            pb.Paint += Pb_Paint;
            this.Controls.Add(pb);
        }

        private void GenerateGeometry()
        {
            vertices.Clear(); edges.Clear(); faces.Clear();
            float s = tbScale.Value / 100f;

            if (currentTask == 0) BuildSurfaceVar1(s);
            else if (currentTask == 1) BuildSurfaceVar2(s);
            else if (currentTask == 2) BuildPolyhedronVar3(s);
            else if (currentTask == 3) BuildPolyhedronVar11(s);

            pb.Invalidate();
        }

        // --- ГЕОМЕТРИЯ ---
        private void BuildSurfaceVar1(float s)
        {
            int steps = 25;
            float step = 6f / steps;
            for (int i = 0; i <= steps; i++)
                for (int j = 0; j <= steps; j++)
                {
                    float x = -3 + i * step;
                    float y = -3 + j * step;
                    float R2 = x * x + y * y;
                    float z = R2 < 0.001f ? 1f : (float)(Math.Sin(R2) / R2);
                    vertices.Add(new Vector4(x * s, z * s, y * s, 1f));
                }

            for (int i = 0; i <= steps; i++)
                for (int j = 0; j <= steps; j++)
                {
                    int idx = i * (steps + 1) + j;
                    if (i < steps) edges.Add(Tuple.Create(idx, idx + steps + 1));
                    if (j < steps) edges.Add(Tuple.Create(idx, idx + 1));
                }
        }

        private void BuildSurfaceVar2(float s)
        {
            int steps = 25;
            float step = 6f / steps;
            for (int i = 0; i <= steps; i++)
                for (int j = 0; j <= steps; j++)
                {
                    float x = -3 + i * step;
                    float y = -3 + j * step;
                    float z = (float)(Math.Pow(Math.Sin(x), 2) + Math.Pow(Math.Sin(y), 2));
                    vertices.Add(new Vector4(x * s, z * s, y * s, 1f));
                }

            for (int i = 0; i <= steps; i++)
                for (int j = 0; j <= steps; j++)
                {
                    int idx = i * (steps + 1) + j;
                    if (i < steps) edges.Add(Tuple.Create(idx, idx + steps + 1));
                    if (j < steps) edges.Add(Tuple.Create(idx, idx + 1));
                }
        }

        private void BuildPolyhedronVar3(float s)
        {
            // Шестигранник (тригональная дипирамида)
            vertices.Add(new Vector4(0, 1.6f * s, 0, 1f));
            vertices.Add(new Vector4(0, -1.6f * s, 0, 1f));
            vertices.Add(new Vector4(1.2f * s, 0, 0, 1f));
            vertices.Add(new Vector4(-0.6f * s, 0, 1.04f * s, 1f));
            vertices.Add(new Vector4(-0.6f * s, 0, -1.04f * s, 1f));

            edges.Add(Tuple.Create(0, 2)); edges.Add(Tuple.Create(0, 3)); edges.Add(Tuple.Create(0, 4));
            edges.Add(Tuple.Create(1, 2)); edges.Add(Tuple.Create(1, 3)); edges.Add(Tuple.Create(1, 4));
            edges.Add(Tuple.Create(2, 3)); edges.Add(Tuple.Create(3, 4)); edges.Add(Tuple.Create(4, 2));

            // Грани для алгоритма Робертса (нормали в объектном пространстве)
            faces.Add(new Face(new Vector3(0, 1, 0), 0));
            faces.Add(new Face(new Vector3(0.866f, 0.5f, 0), 0));
            faces.Add(new Face(new Vector3(-0.433f, 0.5f, 0.75f), 0));
            faces.Add(new Face(new Vector3(-0.433f, 0.5f, -0.75f), 0));
            faces.Add(new Face(new Vector3(0, -1, 0), 0));
            faces.Add(new Face(new Vector3(0.866f, -0.5f, 0), 0));
            faces.Add(new Face(new Vector3(-0.433f, -0.5f, 0.75f), 0));
            faces.Add(new Face(new Vector3(-0.433f, -0.5f, -0.75f), 0));
        }

        private void BuildPolyhedronVar11(float s)
        {
            int n = 5;
            float step = 2f * (float)Math.PI / n;
            for (int i = 0; i < n; i++)
            {
                float a = i * step;
                vertices.Add(new Vector4((float)Math.Cos(a) * s, 1.2f * s, (float)Math.Sin(a) * s, 1f));
                vertices.Add(new Vector4((float)Math.Cos(a) * s, -1.2f * s, (float)Math.Sin(a) * s, 1f));
            }
            for (int i = 0; i < n; i++)
            {
                int t = i * 2, b = i * 2 + 1;
                int nt = ((i + 1) % n) * 2, nb = ((i + 1) % n) * 2 + 1;
                edges.Add(Tuple.Create(t, nt));
                edges.Add(Tuple.Create(b, nb));
                edges.Add(Tuple.Create(t, b));
            }
        }

        // --- МАТРИЦЫ (РУЧНАЯ СБОРКА ДЛЯ .NET 4.7.2) ---
        private Matrix4x4 CreateLookAt(Vector3 eye, Vector3 target, Vector3 up)
        {
            Vector3 z = Vector3.Normalize(eye - target);
            Vector3 x = Vector3.Normalize(Vector3.Cross(up, z));
            Vector3 y = Vector3.Cross(z, x);
            return new Matrix4x4(
                x.X, y.X, z.X, 0,
                x.Y, y.Y, z.Y, 0,
                x.Z, y.Z, z.Z, 0,
                -Vector3.Dot(x, eye), -Vector3.Dot(y, eye), -Vector3.Dot(z, eye), 1);
        }

        private Matrix4x4 CreatePerspective(float fov, float aspect, float near, float far)
        {
            float f = 1.0f / (float)Math.Tan(fov / 2);
            return new Matrix4x4(
                f / aspect, 0, 0, 0,
                0, f, 0, 0,
                0, 0, far / (near - far), -1,
                0, 0, (near * far) / (near - far), 0);
        }

        private Matrix4x4 CreateOrthographic(float width, float height, float near, float far)
        {
            return new Matrix4x4(
                2 / width, 0, 0, 0,
                0, 2 / height, 0, 0,
                0, 0, -2 / (far - near), 0,
                0, 0, -(far + near) / (far - near), 1);
        }

        private Matrix4x4 GetMVP()
        {
            float ry = tbRotY.Value * (float)Math.PI / 180f;
            float s = tbScale.Value / 100f;
            float off = tbOffset.Value / 100f;

            // Модель
            modelMatrix = Matrix4x4.CreateScale(s, s, s) *
                          Matrix4x4.CreateRotationY(ry) *
                          Matrix4x4.CreateTranslation(0, 0, 0);

            // Вид и Проекция в зависимости от варианта
            if (currentTask == 2) // Вариант 3: 2 точки схода
            {
                viewMatrix = CreateLookAt(new Vector3(3.5f, 2f, 4f), Vector3.Zero, new Vector3(0, 1, 0));
                projMatrix = CreatePerspective(0.9f, (float)pb.Width / pb.Height, 0.1f, 100f);
            }
            else if (currentTask == 3) // Вариант 11: Диметрия
            {
                Matrix4x4 rotY = Matrix4x4.CreateRotationY((float)(35.264 * Math.PI / 180));
                Matrix4x4 rotX = Matrix4x4.CreateRotationX((float)(45.0 * Math.PI / 180));
                viewMatrix = Matrix4x4.Identity;
                projMatrix = rotY * rotX * CreateOrthographic(6, 6, 0.1f, 100f);
            }
            else // Варианты 1,2: Ортография для обзора
            {
                viewMatrix = CreateLookAt(new Vector3(0, 0, 5), Vector3.Zero, new Vector3(0, 1, 0));
                projMatrix = CreateOrthographic(8, 8, 0.1f, 100f);
            }

            // Viewport
            vpMatrix = Matrix4x4.CreateScale(pb.Width / 2f, -pb.Height / 2f, 1f) *
                       Matrix4x4.CreateTranslation(pb.Width / 2f, pb.Height / 2f, 0f);

            return modelMatrix * viewMatrix * projMatrix * vpMatrix;
        }

        // --- ОТРИСОВКА И РОБЕРТС ---
        private void Pb_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.Clear(Color.White);
            DrawAxes(e.Graphics);

            Matrix4x4 mvp = GetMVP();
            List<PointF> projected = new List<PointF>();

            foreach (var v in vertices)
            {
                Vector4 t = Vector4.Transform(v, mvp);
                if (t.W != 0) t /= t.W;
                projected.Add(new PointF(t.X, t.Y));
            }

            // Алгоритм Робертса (упрощённый тест видимости по полупространствам граней)
            bool[] visible = new bool[edges.Count];
            for (int i = 0; i < edges.Count; i++)
            {
                visible[i] = IsEdgeVisibleRoberts(edges[i].Item1, edges[i].Item2, mvp);
            }

            using (Pen penSolid = new Pen(Color.Black, 2))
            using (Pen penHidden = new Pen(Color.Gray, 1) { DashStyle = DashStyle.Dash })
            {
                for (int i = 0; i < edges.Count; i++)
                {
                    e.Graphics.DrawLine(visible[i] ? penSolid : penHidden,
                        projected[edges[i].Item1], projected[edges[i].Item2]);
                }
            }
        }

        private bool IsEdgeVisibleRoberts(int v1, int v2, Matrix4x4 mvp)
        {
            // Для поверхностей всё видимо
            if (currentTask < 2) return true;

            // Тест Робертса: ребро видимо, если его середина лежит перед всеми гранями
            Vector4 p1 = Vector4.Transform(vertices[v1], mvp);
            Vector4 p2 = Vector4.Transform(vertices[v2], mvp);
            Vector4 mid = (p1 + p2) / 2f;

            // Преобразуем нормали граней в пространство вида
            Matrix4x4 mv = modelMatrix * viewMatrix;
            Matrix4x4 invMv;
            Matrix4x4.Invert(mv, out invMv);
            Matrix4x4 transposeInvMv = Matrix4x4.Transpose(invMv);

                foreach (var face in faces)
            {
                    Vector3 normalView = Vector3.TransformNormal(face.Normal, transposeInvMv);
                    // Уравнение плоскости в view-space: N·P + D = 0
                    // Проверяем знак для середины ребра
                    float dist = Vector3.Dot(normalView, new Vector3(mid.X, mid.Y, mid.Z)) + face.D;
                if (dist < -0.01f) return false; // За гранью
            }
            return true;
        }

        private void DrawAxes(Graphics g)
        {
            using (Pen axisPen = new Pen(Color.Red, 2))
            using (Pen gridPen = new Pen(Color.LightGray, 1))
            {
                int cx = pb.Width / 2, cy = pb.Height / 2;
                g.DrawLine(axisPen, cx, 0, cx, pb.Height);
                g.DrawLine(axisPen, 0, cy, pb.Width, cy);

                using (Font f = new Font("Arial", 10, FontStyle.Bold))
                {
                    g.DrawString("Y", f, Brushes.Red, cx + 5, 10);
                    g.DrawString("X", f, Brushes.Red, pb.Width - 20, cy - 15);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbTask.SelectedIndexChanged += (s, ev) => tbOffset.Visible = (currentTask == 2);
        }
    }

    public struct Face
    {
        public Vector3 Normal;
        public float D;
        public Face(Vector3 n, float d) { Normal = n; D = d; }
    }
}