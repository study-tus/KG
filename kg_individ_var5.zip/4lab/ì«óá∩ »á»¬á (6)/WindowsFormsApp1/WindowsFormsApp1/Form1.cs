﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        // 3D точка 
        public class Vector3
        {
            public double X, Y, Z, W;
            public Vector3(double x, double y, double z) { X = x; Y = y; Z = z; W = 1; }
        }

        // Вершины тетраэдра
        Vector3[] tetraVertices = {
            new Vector3(0, 1.224, 0),                          // Верхняя (высота по Y)
            new Vector3(0, -0.408, 1.155),                     // Передняя
            new Vector3(-1.0, -0.408, -0.577),                 // Левая
            new Vector3(1.0, -0.408, -0.577)                   // Правая
        };

        // Оси 
        Vector3[] axisVertices = {
            new Vector3(0, 0, 0), new Vector3(2.5, 0, 0), // X
            new Vector3(0, 0, 0), new Vector3(0, 2.5, 0), // Y
            new Vector3(0, 0, 0), new Vector3(0, 0, 2.5)  // Z
        };

        double angleX = 15 * Math.PI / 180, angleY = 35 * Math.PI / 180, angleZ = 0;
        double transX = 0, transY = 0;
        double scaleX = 100, scaleY = 100, scaleZ = 100;
        double rotSpeedY = 0.02;
        bool isAnimating = true;

        public Form1()
        {
            this.DoubleBuffered = true;
            this.Text = "Программный комплекс 3D-визуализации // Лабораторная работа";
            this.Size = new Size(950, 720);
            this.StartPosition = FormStartPosition.CenterScreen;

            Timer timer = new Timer();
            timer.Interval = 16;
            timer.Tick += (s, e) => {
                if (isAnimating) { angleY += rotSpeedY; this.Invalidate(); }
            };
            timer.Start();

            this.KeyDown += Form1_KeyDown;
        }

        // --- ЯДРО АЛГОРИТМОВ  ---
        private double[,] MultiplyMatrix(double[,] a, double[,] b)
        {
            double[,] result = new double[4, 4];
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    for (int k = 0; k < 4; k++)
                        result[i, j] += a[i, k] * b[k, j];
            return result;
        }

        private Vector3 TransformPoint(Vector3 p, double[,] m)
        {
            return new Vector3(
                p.X * m[0, 0] + p.Y * m[0, 1] + p.Z * m[0, 2] + p.W * m[0, 3],
                p.X * m[1, 0] + p.Y * m[1, 1] + p.Z * m[1, 2] + p.W * m[1, 3],
                p.X * m[2, 0] + p.Y * m[2, 1] + p.Z * m[2, 2] + p.W * m[2, 3]
            );
        }

        private double[,] GetTransformationMatrix()
        {
            double[,] rx = { { 1, 0, 0, 0 }, { 0, Math.Cos(angleX), -Math.Sin(angleX), 0 }, { 0, Math.Sin(angleX), Math.Cos(angleX), 0 }, { 0, 0, 0, 1 } };
            double[,] ry = { { Math.Cos(angleY), 0, Math.Sin(angleY), 0 }, { 0, 1, 0, 0 }, { -Math.Sin(angleY), 0, Math.Cos(angleY), 0 }, { 0, 0, 0, 1 } };
            double[,] rz = { { Math.Cos(angleZ), -Math.Sin(angleZ), 0, 0 }, { Math.Sin(angleZ), Math.Cos(angleZ), 0, 0 }, { 0, 0, 1, 0 }, { 0, 0, 0, 1 } };
            double[,] s = { { scaleX, 0, 0, 0 }, { 0, scaleY, 0, 0 }, { 0, 0, scaleZ, 0 }, { 0, 0, 0, 1 } };

            return MultiplyMatrix(MultiplyMatrix(MultiplyMatrix(rx, ry), rz), s);
        }

        private PointF Project(Vector3 p)
        {
            return new PointF((float)(this.ClientSize.Width / 2 + p.X + transX),
                              (float)(this.ClientSize.Height / 2 - p.Y - transY));
        }
        // ---------------------------------------

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // Инициализация графического контекста (инженерный холст)
            Graphics blueprintCanvas = e.Graphics;
            blueprintCanvas.SmoothingMode = SmoothingMode.AntiAlias;

            // 1. Оформление фона: Светлый конструкторский градиент (CAD Paper)
            using (var backgroundBrush = new LinearGradientBrush(
                this.ClientRectangle,
                Color.FromArgb(235, 237, 240), // Светло-серый
                Color.FromArgb(215, 220, 225), // Инженерный стальной
                45F))
            {
                blueprintCanvas.FillRectangle(backgroundBrush, this.ClientRectangle);
            }

            // Метрика экрана (Viewport)
            float centerX = this.ClientSize.Width / 2f;
            float centerY = this.ClientSize.Height / 2f;

            // Абсолютно фиксированная точка центра для координатной сетки осей
            PointF gridOrigin = new PointF(centerX, centerY);

            // 2. СТАТИЧНЫЕ КООРДИНАТНЫЕ ОСИ (С исправленным направлением Y вверх)
            float axisScaleX = this.ClientSize.Width * 0.35f;
            float axisScaleY = this.ClientSize.Height * 0.35f;

            // Корректные математические направления на экране WinForms:
            PointF endPointX = new PointF(gridOrigin.X + axisScaleX, gridOrigin.Y);                      // Вправо
            PointF endPointY = new PointF(gridOrigin.X, gridOrigin.Y - axisScaleY);                      // Строго ВВЕРХ (минус по экрану)
            PointF endPointZ = new PointF(gridOrigin.X - axisScaleX * 0.5f, gridOrigin.Y + axisScaleY * 0.5f); // По диагонали вниз-влево

            // Тонкие чертежные линии для осей (Графит / Темный синий / Приглушенный бордовый)
            using (Pen graphitePenX = new Pen(Color.FromArgb(180, 50, 70), 1f))
            using (Pen graphitePenY = new Pen(Color.FromArgb(40, 140, 100), 1f))
            using (Pen graphitePenZ = new Pen(Color.FromArgb(50, 90, 160), 1f))
            {
                blueprintCanvas.DrawLine(graphitePenX, gridOrigin, endPointX);
                blueprintCanvas.DrawLine(graphitePenY, gridOrigin, endPointY);
                blueprintCanvas.DrawLine(graphitePenZ, gridOrigin, endPointZ);

                // Строгие шрифтовые маркеры осей с правильными отступами
                using (Font CADFont = new Font("Arial", 9f, FontStyle.Bold))
                {
                    blueprintCanvas.DrawString("X", CADFont, Brushes.DarkRed, endPointX.X + 5, endPointX.Y - 7);
                    blueprintCanvas.DrawString("Y", CADFont, Brushes.DarkGreen, endPointY.X - 18, endPointY.Y - 18);
                    blueprintCanvas.DrawString("Z", CADFont, Brushes.DarkBlue, endPointZ.X - 45, endPointZ.Y + 5);
                }
            }

            // 3. ОБРАБОТКА ТРЕХМЕРНОЙ ГЕОМЕТРИИ ТЕЛА
            double[,] modelMatrix = GetTransformationMatrix();
            Vector3[] dynamicPoints = tetraVertices.Select(v => TransformPoint(v, modelMatrix)).ToArray();

            // Таблица связей полигонов (Грани тетраэдра)
            int[][] indexFaces = {
        new int[] { 0, 1, 2 },
        new int[] { 0, 2, 3 },
        new int[] { 0, 3, 1 },
        new int[] { 1, 3, 2 }
    };

            bool[] renderVertexFlags = new bool[dynamicPoints.Length];

            // Рендеринг полигонов с использованием алгоритма отсечения Робертса
            foreach (var face in indexFaces)
            {
                var pt0 = dynamicPoints[face[0]];
                var pt1 = dynamicPoints[face[1]];
                var pt2 = dynamicPoints[face[2]];

                // Вычисление компонент нормали
                double dX = (pt1.Y - pt0.Y) * (pt2.Z - pt0.Z) - (pt1.Z - pt0.Z) * (pt2.Y - pt0.Y);
                double dY = (pt1.Z - pt0.Z) * (pt2.X - pt0.X) - (pt1.X - pt0.X) * (pt2.Z - pt0.Z);
                double dZ = (pt1.X - pt0.X) * (pt2.Y - pt0.Y) - (pt1.Y - pt0.Y) * (pt2.X - pt0.X);

                // Условие видимости плоскости (nz < 0)
                if (dZ < 0)
                {
                    // Маркируем вершины видимой грани
                    renderVertexFlags[face[0]] = true;
                    renderVertexFlags[face[1]] = true;
                    renderVertexFlags[face[2]] = true;

                    PointF[] visiblePolygon = { Project(pt0), Project(pt1), Project(pt2) };

                    // ТЕМА "WHITE CAD": Матовое полупрозрачное стекло с бирюзовым оттенком
                    using (Brush glassBrush = new SolidBrush(Color.FromArgb(60, 0, 168, 204)))
                        blueprintCanvas.FillPolygon(glassBrush, visiblePolygon);

                    // Ребра: Тонкий матовый темно-серый контур
                    using (Pen boundaryPen = new Pen(Color.FromArgb(45, 52, 54), 1.3f))
                        blueprintCanvas.DrawPolygon(boundaryPen, visiblePolygon);
                }
            }

            // 4. ТЕХНИЧЕСКИЕ МАРКЕРЫ ВЕРШИН
            for (int i = 0; i < dynamicPoints.Length; i++)
            {
                if (renderVertexFlags[i])
                {
                    PointF vertexScreenPos = Project(dynamicPoints[i]);
                    // Точка закрашивается глубоким графитовым цветом
                    blueprintCanvas.FillEllipse(Brushes.DarkSlateGray, vertexScreenPos.X - 3f, vertexScreenPos.Y - 3f, 6, 6);

                    // Защитное белое обрамление для контраста
                    using (Pen outlinePen = new Pen(Color.White, 1f))
                    {
                        blueprintCanvas.DrawEllipse(outlinePen, vertexScreenPos.X - 4f, vertexScreenPos.Y - 4f, 8, 8);
                    }
                }
            }

            // 5. ИНФОРМАЦИОННАЯ ПАНЕЛЬ HUD (Профессиональный стиль документации)
            string infoOverlay = "SYSTEM INTERFACE\n" +
                                 "──────────────────────────────\n" +
                                 "Стрелки      :: Смещение объекта\n" +
                                 "W / S        :: Масштабирование (XZ)\n" +
                                 "A / D        :: Масштабирование (Y)\n" +
                                 "Q / E        :: скорость и направление анимации\n" +
                                 "P            :: Фиксация анимации\n" +
                                 "R            :: Инверсия по оси Z";

            Rectangle infoPanelArea = new Rectangle(20, 20, 275, 160);

            // Контур блока подсказок без заливки (чистый минимализм)
            using (SolidBrush panelBgBrush = new SolidBrush(Color.FromArgb(120, 255, 255, 255)))
            using (Pen panelFramePen = new Pen(Color.FromArgb(160, 45, 52, 54), 1))
            {
                blueprintCanvas.FillRectangle(panelBgBrush, infoPanelArea);
                blueprintCanvas.DrawRectangle(panelFramePen, infoPanelArea);
            }

            using (Font infoFont = new Font("Arial", 9f, FontStyle.Regular))
            {
                blueprintCanvas.DrawString(infoOverlay, infoFont, Brushes.DarkSlateGray, 30, 28);
            }
        }

        // Измененные кнопки управления 
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            double moveStep = 15;
            double scaleStep = 10;

            switch (e.KeyCode)
            {
                // Сдвиг
                case Keys.Up: transY += moveStep; break;
                case Keys.Down: transY -= moveStep; break;
                case Keys.Left: transX -= moveStep; break;
                case Keys.Right: transX += moveStep; break;

                // Масштаб X/Z 
                case Keys.W: scaleX += scaleStep; scaleZ += scaleStep; break;
                case Keys.S: scaleX = Math.Max(10, scaleX - scaleStep); scaleZ = scaleX; break;

                // Масштаб Y 
                case Keys.A: scaleY += scaleStep; break;
                case Keys.D: scaleY = Math.Max(10, scaleY - scaleStep); break;

                // Изменение скорости вращения 
                case Keys.E: rotSpeedY += 0.005; break;
                case Keys.Q: rotSpeedY -= 0.005; break;

                // Пауза теперь на "P"
                case Keys.P: isAnimating = !isAnimating; break;

                // Отражение
                case Keys.R:
                    for (int i = 0; i < tetraVertices.Length; i++) tetraVertices[i].Z *= -1;
                    break;
            }
            this.Invalidate();
        }
    }
}